#!/usr/bin/env bash
# Подготовка hamster-bot к запуску на macOS (Intel и Apple Silicon M1 и новее).
# Запуск один раз после распаковки архива:  bash mac_sign.sh
#  - снимает карантин (файлы, скачанные из интернета, macOS блокирует);
#  - делает hb_c и .sh исполняемыми (zip, собранный на Windows, не хранит права);
#  - подписывает hb_c локальной (ad-hoc) подписью: на Apple Silicon неподписанный
#    arm64-файл сразу завершается с "killed: 9".
set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

EXE_PATH="./hb_c"

if [[ ! -f "$EXE_PATH" ]]; then
    echo "Executable not found: '$EXE_PATH'"
    exit 1
fi

echo "Removing quarantine attribute..."
xattr -dr com.apple.quarantine . 2>/dev/null || true

echo "Setting executable permissions..."
chmod +x "$EXE_PATH"
chmod +x ./*.sh 2>/dev/null || true

echo "Signing $EXE_PATH (ad-hoc)..."
if ! codesign --force --sign - "$EXE_PATH"; then
    echo
    echo "codesign failed. Install Xcode Command Line Tools: xcode-select --install"
    exit 1
fi

codesign --verify --verbose "$EXE_PATH" && echo && echo "Done. Run: ./hb_c"
exit 0
