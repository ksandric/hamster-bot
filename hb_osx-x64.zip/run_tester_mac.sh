#!/usr/bin/env bash
set -u
set -o pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

EXE_PATH="./hb_c"

if [[ ! -f "$EXE_PATH" ]]; then
    echo
    echo "Compiled executable not found: '$EXE_PATH'"
    echo "Build Release osx-x64 first."
    exit 1
fi

if [[ ! -x "$EXE_PATH" ]]; then
    chmod +x "$EXE_PATH"
fi

echo "Running tester..."
"$EXE_PATH" --run-tester
EXIT_CODE=$?

if [[ $EXIT_CODE -ne 0 ]]; then
    echo
    echo "Tester failed with exit code $EXIT_CODE."
    exit $EXIT_CODE
fi

echo
echo "Tester finished."
exit 0