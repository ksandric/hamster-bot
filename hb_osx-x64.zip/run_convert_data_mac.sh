#!/usr/bin/env bash
set -u
set -o pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

EXE_PATH="./hb_c"

if [[ ! -f "$EXE_PATH" ]]; then
    echo
    echo "Compiled executable not found: '$EXE_PATH'"
    echo "Build Release osx-x64 first."
    exit 1
fi

if [[ ! -x "$EXE_PATH" ]]; then
    chmod +x "$EXE_PATH"
fi

echo "Converting tester data (*_1m.csv to Parquet)..."
"$EXE_PATH" --convert-data
EXIT_CODE=$?

if [[ $EXIT_CODE -ne 0 ]]; then
    echo
    echo "Conversion finished with errors, exit code $EXIT_CODE."
    exit $EXIT_CODE
fi

echo
echo "Conversion finished."
exit 0