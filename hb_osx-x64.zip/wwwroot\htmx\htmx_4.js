// HTMX dashboard JavaScript
var THEME_KEY = 'htmx-theme';

    (function initTheme() {
      var savedTheme = localStorage.getItem(THEME_KEY) || 'liquid-glass';
      var themeRadio = document.querySelector('input.theme-controller[value="' + savedTheme + '"]');
      if (!themeRadio) {
        savedTheme = 'light';
      }

      document.documentElement.setAttribute('data-theme', savedTheme);

      themeRadio = document.querySelector('input.theme-controller[value="' + savedTheme + '"]');
      if (themeRadio) themeRadio.checked = true;

      document.querySelectorAll('.theme-controller').forEach(function (radio) {
        radio.addEventListener('change', function (e) {
          localStorage.setItem(THEME_KEY, e.target.value);
          document.documentElement.setAttribute('data-theme', e.target.value);
        });
      });
    })();

var DENSITY_KEY = 'htmx-density';

function applyDensity(compact) {
  if (compact) {
    document.documentElement.setAttribute('data-density', 'compact');
  } else {
    document.documentElement.removeAttribute('data-density');
  }
  document.querySelectorAll('.density-toggle-btn').forEach(function (btn) {
    btn.classList.toggle('btn-active', compact);
    btn.setAttribute('aria-pressed', compact ? 'true' : 'false');
  });
}

function toggleCompactDensity() {
  var compact = localStorage.getItem(DENSITY_KEY) !== 'compact';
  localStorage.setItem(DENSITY_KEY, compact ? 'compact' : 'comfortable');
  applyDensity(compact);
}

(function initDensity() {
  applyDensity(localStorage.getItem(DENSITY_KEY) === 'compact');
})();

    function showErrorToast(message) {
      var toast = document.createElement('div');
      toast.className = 'toast-item cursor-pointer transition-opacity duration-500';
      toast.innerHTML = '<div class="alert alert-error shadow-lg mb-2 text-white"><span>' + message + '</span></div>';
      document.getElementById('toast-container').appendChild(toast);
    }

    function dismissToast(toast) {
      if (!toast || toast.dataset.toastDismissing === '1') return;
      toast.dataset.toastDismissing = '1';
      toast.style.opacity = '0';
      setTimeout(function () {
        if (toast && toast.parentNode) toast.remove();
      }, 500);
    }

    function wireToast(toast) {
      if (!toast || toast.dataset.toastWired === '1') return;
      toast.dataset.toastWired = '1';
      toast.classList.add('cursor-pointer');
      toast.addEventListener('click', function () { dismissToast(toast); });
      setTimeout(function () { dismissToast(toast); }, 20000);
    }

    function initToastBehavior() {
      var container = document.getElementById('toast-container');
      if (!container) return;

      container.querySelectorAll(':scope > div').forEach(function (toast) {
        wireToast(toast);
      });

      var observer = new MutationObserver(function (mutations) {
        mutations.forEach(function (mutation) {
          mutation.addedNodes.forEach(function (node) {
            if (!(node instanceof HTMLElement)) return;
            if (node.parentElement === container) {
              wireToast(node);
            }
          });
        });
      });

      observer.observe(container, { childList: true });
    }

    initToastBehavior();

    document.body.addEventListener('htmx:beforeRequest', function (evt) {
      var elt = evt.detail && evt.detail.elt ? evt.detail.elt : null;
      if (elt && elt.hasAttribute('data-disable-on-request')) {
        elt.disabled = true;
        elt.dataset.htmxPendingRestore = '1';
      }
      var form = elt ? elt.closest('form') : null;
      if (form) {
        var buttons = form.querySelectorAll('button[type="submit"]');
        buttons.forEach(function (b) { b.disabled = true; });
      }
    });

    document.body.addEventListener('htmx:afterRequest', function (evt) {
      var elt = evt.detail && evt.detail.elt ? evt.detail.elt : null;
      if (elt && elt.dataset.htmxPendingRestore === '1') {
        elt.disabled = false;
        delete elt.dataset.htmxPendingRestore;
      }
      var form = elt ? elt.closest('form') : null;
      if (form) {
        var buttons = form.querySelectorAll('button[type="submit"]');
        buttons.forEach(function (b) { b.disabled = false; });
      }
    });

    document.body.addEventListener('htmx:responseError', function (evt) {
      var xhr = evt.detail && evt.detail.xhr ? evt.detail.xhr : null;
      var status = xhr ? xhr.status : 0;
      var responseText = xhr && typeof xhr.responseText === 'string' ? xhr.responseText : '';
      var backendToastShown = false;

      if (responseText) {
        var wrapper = document.createElement('div');
        wrapper.innerHTML = responseText;

        var oobToasts = wrapper.querySelectorAll('.toast-item');
        if (oobToasts.length > 0) {
          var toastContainer = document.getElementById('toast-container');
          oobToasts.forEach(function (toast) {
            if (!toastContainer) return;
            toastContainer.appendChild(toast);
            wireToast(toast);
            backendToastShown = true;
          });
        }
      }

      if (!backendToastShown) {
        showErrorToast(status === 401 ? 'Session expired. Please login.' : 'Request failed. Please retry.');
      }

      if (status === 401) {
        window.location.href = '/htmx/login';
      }
    });

// TABLE SORTING AND COLUMN TOGGLING
function sortTable(n) {
    const table = document.getElementById('dataTable');
    let switching = true;
    let dir = 'asc';
    let switchcount = 0;
    while (switching) {
        switching = false;
        const rows = table.rows;
        for (let i = 1; i < rows.length - 1; i++) {
            let shouldSwitch = false;
            const x = rows[i].getElementsByTagName('TD')[n];
            const y = rows[i + 1].getElementsByTagName('TD')[n];
            if (!x || !y) continue;

            const xContent = x.innerText || '';
            const yContent = y.innerText || '';
            const xNum = parseFloat(xContent.replace(',', '.'));
            const yNum = parseFloat(yContent.replace(',', '.'));

            if (!isNaN(xNum) && !isNaN(yNum)) {
                if ((dir === 'asc' && xNum > yNum) || (dir === 'desc' && xNum < yNum)) {
                    shouldSwitch = true;
                }
            } else {
                if ((dir === 'asc' && xContent.toLowerCase() > yContent.toLowerCase()) ||
                    (dir === 'desc' && xContent.toLowerCase() < yContent.toLowerCase())) {
                    shouldSwitch = true;
                }
            }

            if (shouldSwitch) {
                rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
                switching = true;
                switchcount++;
                break;
            }
        }

        if (!switching && switchcount === 0 && dir === 'asc') {
            dir = 'desc';
            switching = true;
        }
    }
}

function toggleColumn(colIndex, toggleButton) {
  let table = null;
  if (toggleButton && toggleButton.parentElement) {
    const maybeTable = toggleButton.parentElement.nextElementSibling;
    if (maybeTable && maybeTable.tagName && maybeTable.tagName.toLowerCase() === 'table') {
      table = maybeTable;
    }
  }

  if (!table) {
    const tables = document.querySelectorAll('table#dataTable');
    for (let i = 0; i < tables.length; i++) {
      if (tables[i] && tables[i].rows && tables[i].rows.length > 0) {
        table = tables[i];
        break;
      }
    }
  }

  if (!table) {
    table = document.getElementById('dataTable');
  }

  if (!table || !table.rows || table.rows.length === 0) return;

  const firstCell = table.rows[0].cells[colIndex];
  const willHide = firstCell && firstCell.style.display !== 'none';

    for (let i = 0; i < table.rows.length; i++) {
        const cell = table.rows[i].cells[colIndex];
        if (cell) {
      cell.style.display = willHide ? 'none' : '';
        }
    }

  if (toggleButton) {
    toggleButton.setAttribute('aria-pressed', willHide ? 'true' : 'false');
    if (toggleButton.classList) {
      toggleButton.classList.toggle('btn-active', willHide);
    }
  }
}

// HTMX DASHBOARD VIEW MANAGEMENT
var VIEW_KEY = 'htmx-dashboard-view';
var viewToUrl = {
    accounts: '/htmx/accounts',
    strategies: '/htmx/strategies',
    system: '/htmx/system',
    tester: '/htmx/tester',
    positions: '/htmx/positions',
    orders: '/htmx/orders',
    log: '/htmx/log',
    config: '/htmx/config',
    botstable: '/htmx/botstable',
    terminal: '/htmx/terminal'
};

function loadView(view, pushHistory) {
    if (!viewToUrl[view] || !window.htmx) return;
    if (!document.getElementById('htmx-content')) return;
    localStorage.setItem(VIEW_KEY, view);

    document.querySelectorAll('.tab').forEach(function (t) { t.classList.remove('tab-active'); });
    var btn = document.querySelector('button.tab[data-view="' + view + '"]');
    if (btn) btn.classList.add('tab-active');

    htmx.ajax('GET', viewToUrl[view], '#htmx-content');
    if (pushHistory) {
        var url = new URL(window.location.href);
        url.searchParams.set('view', view);
        history.pushState({ view: view }, '', url.toString());
    }
}

function currentViewFromUrl() {
    var params = new URLSearchParams(window.location.search);
    var view = params.get('view');
    return viewToUrl[view] ? view : null;
}

function clearModalBody() {
  var modalBody = document.getElementById('htmx-modal-body');
  if (modalBody) {
    modalBody.innerHTML = '';
  }
}

function resizeModalCharts(expandedHeight) {
  var containers = document.querySelectorAll('#htmx-modal-body [id^="id_chart_"]');
  containers.forEach(function (el) {
    if (!el._lwChart) return;
    var newH = expandedHeight != null ? expandedHeight : el._lwDefaultHeight;
    el._lwCurrentHeight = newH;
    el._lwChart.resize(el.getBoundingClientRect().width, newH);
  });
}

function resizeModalChartsDeferred(expandedHeight) {
  [0, 50, 150].forEach(function (delay) {
    setTimeout(function () { resizeModalCharts(expandedHeight); }, delay);
  });
}

function toggleModalExpand() {
  var box = document.getElementById('htmx-modal-box');
  var btn = document.getElementById('htmx-modal-expand');
  if (!box) return;
  var expanded = box.dataset.expanded === '1';
  if (expanded) {
    box.dataset.expanded = '0';
    box.style.maxWidth = '';
    box.style.width = '';
    box.style.maxHeight = '';
    box.style.height = '';
    box.style.borderRadius = '';
    if (btn) btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75h-4.5m4.5 0v4.5m0-4.5L15 9m5.25 11.25h-4.5m4.5 0v-4.5m0 4.5L15 15"/></svg>';
    if (btn) btn.title = 'Expand';
    resizeModalChartsDeferred(null);
  } else {
    box.dataset.expanded = '1';
    box.style.maxWidth = '100vw';
    box.style.width = '100vw';
    box.style.maxHeight = '100vh';
    box.style.height = '100vh';
    box.style.borderRadius = '0';
    if (btn) btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 9L3.75 3.75M9 9H4.5m4.5 0V4.5M15 9l5.25-5.25M15 9h4.5m-4.5 0V4.5M9 15l-5.25 5.25M9 15H4.5m4.5 0v4.5M15 15l5.25 5.25M15 15h4.5m-4.5 0v4.5"/></svg>';
    if (btn) btn.title = 'Restore';
    var expandedH = Math.max(400, window.innerHeight - 280);
    resizeModalChartsDeferred(expandedH);
  }
  window.dispatchEvent(new Event('resize'));
}

function resetModalExpand() {
  var box = document.getElementById('htmx-modal-box');
  if (box && box.dataset.expanded === '1') {
    box.dataset.expanded = '0';
    box.style.maxWidth = '';
    box.style.width = '';
    box.style.maxHeight = '';
    box.style.height = '';
    box.style.borderRadius = '';
    var btn = document.getElementById('htmx-modal-expand');
    if (btn) {
      btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75h-4.5m4.5 0v4.5m0-4.5L15 9m5.25 11.25h-4.5m4.5 0v-4.5m0 4.5L15 15"/></svg>';
      btn.title = 'Expand';
    }
  }
}

function closeDashboardModal() {
  var modal = document.getElementById('htmx-modal');
  if (!modal) {
    return;
  }

  if (modal.open) {
    modal.close();
  }

  clearModalBody();
  resetModalExpand();
}

document.body.addEventListener('htmx:afterSwap', function (evt) {
    if (evt && evt.detail && evt.detail.target && evt.detail.target.id === 'htmx-modal-body') {
    var modal = document.getElementById('htmx-modal');
    if (!modal) return;

    modal.showModal();

    // Some chart widgets measure width before modal open animation ends.
    // Trigger deferred resize notifications so they can fit full modal width.
    [0, 120, 260].forEach(function (delay) {
      setTimeout(function () {
        window.dispatchEvent(new Event('resize'));
      }, delay);
    });
    }
});

  (function bindModalLifecycle() {
    var modal = document.getElementById('htmx-modal');
    if (!modal) {
      return;
    }

    modal.addEventListener('close', function () {
      clearModalBody();
      resetModalExpand();
    });
  })();

document.body.addEventListener('click', function (evt) {
    var button = evt.target.closest('button[data-view]');
    if (!button) return;

    var view = button.getAttribute('data-view');
    if (viewToUrl[view]) {
        localStorage.setItem(VIEW_KEY, view);
        document.querySelectorAll('.tab').forEach(function (t) { t.classList.remove('tab-active'); });
        button.classList.add('tab-active');

        var url = new URL(window.location.href);
        url.searchParams.set('view', view);
        history.replaceState({ view: view }, '', url.toString());
    }
});

document.body.addEventListener('closeModal', function () {
  closeDashboardModal();
});

document.body.addEventListener('accountsChanged', function () {
    loadView('accounts', false);
  closeDashboardModal();
});

document.body.addEventListener('strategiesChanged', function () {
    loadView('strategies', false);
  closeDashboardModal();
});

document.body.addEventListener('botsChanged', function () {
    loadView('botstable', false);
  closeDashboardModal();
});

document.body.addEventListener('testerChanged', function () {
    loadView('tester', false);
});

window.addEventListener('popstate', function (evt) {
    var view = (evt.state && evt.state.view) || currentViewFromUrl() || localStorage.getItem(VIEW_KEY) || 'accounts';
    loadView(view, false);
});

(function initDashboard() {
    if (!document.getElementById('htmx-content')) return;
    var initialView = currentViewFromUrl() || localStorage.getItem(VIEW_KEY) || 'botstable';
    loadView(initialView, false);
})();

/* ===== Y2K / GeoCities style promo widget ===== */
(function () {
  var widget = document.getElementById('y2k-widget');
  var icon = document.getElementById('y2k-icon');
  var closeBtn = document.getElementById('y2k-close');
  var countEl = document.getElementById('y2k-count');
  var badge = document.getElementById('y2k-badge');
  var DISMISS_KEY = 'y2kAdDismissedAt';
  var DISMISS_HOURS = 24;

  if (!widget || !icon || !closeBtn || !countEl) return;

  function isDismissed() {
    var t = localStorage.getItem(DISMISS_KEY);
    if (!t) return false;
    return (Date.now() - parseInt(t, 10)) < DISMISS_HOURS * 3600 * 1000;
  }

  icon.addEventListener('click', function (e) {
    if (e) e.preventDefault();
    widget.classList.toggle('open');
    if (badge) badge.style.display = 'none';
  });

  closeBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    widget.classList.remove('open');
    localStorage.setItem(DISMISS_KEY, Date.now().toString());
  });

  if (isDismissed()) {
    if (badge) badge.style.display = 'none';
    return;
  }

  var base = 482 + Math.floor(Math.random() * 40);
  countEl.textContent = String(base).padStart(6, '0');
  setInterval(function () {
    base += Math.floor(Math.random() * 3);
    countEl.textContent = String(base).padStart(6, '0');
  }, 4000);
})();
/* ===== End Y2K / GeoCities style promo widget ===== */

// END OF FILE
