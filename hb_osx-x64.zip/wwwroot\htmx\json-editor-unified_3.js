(function () {
  if (typeof window === 'undefined') return;

  function decodeBase64Utf8(base64) {
    var bytes = Uint8Array.from(atob(base64), function (c) {
      return c.charCodeAt(0);
    });
    return new TextDecoder('utf-8').decode(bytes);
  }

  // Тип схемы — строка или union-массив ['object', 'null']
  function schemaHasType(s, type) {
    if (!s) return false;
    return Array.isArray(s.type) ? s.type.indexOf(type) !== -1 : s.type === type;
  }

  // Схема элементов пустого массива — заглушка, при объединении уступает реальной схеме
  var emptyItemsSchemas = typeof WeakSet === 'function' ? new WeakSet() : null;

  function isEmptyItemsSchema(s) {
    return !!(emptyItemsSchemas && s && emptyItemsSchemas.has(s));
  }

  function withNullType(s) {
    if (schemaHasType(s, 'null')) return s;
    var copy = Object.assign({}, s);
    copy.type = (Array.isArray(s.type) ? s.type : [s.type]).concat(['null']);
    // enum [true, false] у булевых не пропустил бы null при валидации
    delete copy.enum;
    return copy;
  }

  // Объединение схем элементов массива: в settings[] у mrs2-настройки zigzag = null, а у zigzag-настройки — объект.
  // Со схемой только по первому элементу json-editor отдавал разделы стратегий остальных элементов как null
  function mergeSchemas(a, b) {
    if (!a || isEmptyItemsSchema(a)) return b;
    if (!b || isEmptyItemsSchema(b)) return a;

    var aNull = a.type === 'null';
    var bNull = b.type === 'null';
    if (aNull && bNull) return a;
    if (aNull) return withNullType(b);
    if (bNull) return withNullType(a);

    var nullable = schemaHasType(a, 'null') || schemaHasType(b, 'null');
    var merged = a;
    if (schemaHasType(a, 'object') && schemaHasType(b, 'object')) {
      var props = {};
      Object.keys(a.properties || {}).forEach(function (k) {
        props[k] = mergeSchemas(a.properties[k], (b.properties || {})[k]);
      });
      Object.keys(b.properties || {}).forEach(function (k) {
        if (!Object.prototype.hasOwnProperty.call(props, k)) props[k] = b.properties[k];
      });
      merged = { type: 'object', properties: props, additionalProperties: true };
    } else if (schemaHasType(a, 'array') && schemaHasType(b, 'array')) {
      merged = { type: 'array', items: mergeSchemas(a.items, b.items) };
    }
    // Разные непустые типы (число и строка) — остаётся схема первого, как раньше
    return nullable ? withNullType(merged) : merged;
  }

  function inferSchema(value) {
    if (value === null) return { type: 'null' };

    if (Array.isArray(value)) {
      if (value.length === 0) {
        var emptyItems = { type: 'string' };
        if (emptyItemsSchemas) emptyItemsSchemas.add(emptyItems);
        return { type: 'array', items: emptyItems };
      }
      var items = inferSchema(value[0]);
      for (var i = 1; i < value.length; i++) {
        items = mergeSchemas(items, inferSchema(value[i]));
      }
      return { type: 'array', items: items };
    }

    var t = typeof value;
    if (t === 'string') return { type: 'string' };
    if (t === 'number') return Number.isInteger(value) ? { type: 'number' } : { type: 'number' };
    if (t === 'boolean') return { type: 'boolean', format: 'select', enum: [true, false] };

    if (t === 'object') {
      var props = {};
      Object.keys(value).forEach(function (k) {
        props[k] = inferSchema(value[k]);
      });
      return {
        type: 'object',
        properties: props,
        additionalProperties: true
      };
    }

    return { type: 'string' };
  }

  function appendToastFromHtml(htmlText) {
    if (!htmlText) return;
    var container = document.getElementById('toast-container');
    if (!container) return;

    var wrapper = document.createElement('div');
    wrapper.innerHTML = htmlText;
    var toastNode = wrapper.querySelector('.toast-item');
    if (!toastNode) return;

    container.appendChild(toastNode);
    if (typeof window.wireToast === 'function') {
      window.wireToast(toastNode);
    }
  }

  function getInitialValue(options) {
    if (options.initialValue) return options.initialValue;

    var b64NodeId = options.initialJsonBase64Id;
    if (!b64NodeId) return {};

    var node = document.getElementById(b64NodeId);
    if (!node) throw new Error('Initial JSON base64 node not found: ' + b64NodeId);

    var b64Text = (node.textContent || '').trim();
    if (!b64Text) return {};

    var jsonText = decodeBase64Utf8(b64Text);
    return JSON.parse(jsonText || '{}');
  }

  function postInit(container, editor) {
    function isSectionExpanded(section) {
      if (!section) return false;
      try {
        var panel = section.querySelector(':scope > .je-indented-panel');
        if (panel) {
          return window.getComputedStyle(panel).display !== 'none';
        }
      } catch (e) { /* ignore */ }
      return section.classList.contains('expanded');
    }

    function isToggleExpanded(btn, section) {
      if (!btn) return false;

      // Most reliable source in this JSONEditor build: button text toggles Expand/Collapse.
      try {
        var span = btn.querySelector('span');
        var spanText = ((span && span.textContent) || '').trim().toLowerCase();
        if (spanText.indexOf('collapse') !== -1 || spanText.indexOf('свернуть') !== -1) return true;
        if (spanText.indexOf('expand') !== -1 || spanText.indexOf('развернуть') !== -1) return false;
      } catch (e) { /* ignore */ }

      if (!section) return btn.classList.contains('hb-expanded');
      return isSectionExpanded(section);
    }

    function getSectionToggle(section) {
      if (!section) return null;
      return section.querySelector(':scope > .je-header .json-editor-btntype-toggle');
    }

    function syncToggleState(btn) {
      try {
        var parent = btn.closest('[data-schemapath]');
        var expanded = isToggleExpanded(btn, parent);
        if (expanded) {
          btn.classList.add('hb-expanded');
          btn.setAttribute('data-hb-sign', '-');
        } else {
          btn.classList.remove('hb-expanded');
          btn.setAttribute('data-hb-sign', '+');
        }
      } catch (e) { /* ignore */ }
    }

    function syncAllToggleStates() {
      try {
        var buttons = container.querySelectorAll('.json-editor-btntype-toggle');
        buttons.forEach(function (btn) {
          if (btn.classList.contains('hb-root-hidden')) return;
          syncToggleState(btn);
        });
      } catch (e) { /* ignore */ }
    }

    function wireToggleButton(btn) {
      if (!btn || btn.classList.contains('hb-root-hidden')) return;
      if (btn.dataset.hbToggleWired === '1') return;
      btn.dataset.hbToggleWired = '1';

      // Initialize sign immediately.
      syncToggleState(btn);

      // Sync after click once JSONEditor updates internal state/text.
      btn.addEventListener('click', function () {
        setTimeout(function () {
          syncToggleState(btn);
          syncAllToggleStates();
        }, 0);
        setTimeout(function () {
          syncToggleState(btn);
          syncAllToggleStates();
        }, 50);
        if (typeof requestAnimationFrame === 'function') {
          requestAnimationFrame(function () {
            syncToggleState(btn);
            syncAllToggleStates();
          });
        }
      });

      // The library reliably flips button text Expand/Collapse, so observe it directly.
      try {
        var span = btn.querySelector('span');
        if (span && typeof MutationObserver !== 'undefined') {
          var spanObserver = new MutationObserver(function () {
            syncToggleState(btn);
          });
          spanObserver.observe(span, { childList: true, characterData: true, subtree: true });
        }
      } catch (e) { /* ignore */ }
    }

    function collapseAllInitially() {
      try {
        var sections = container.querySelectorAll('[data-schemapath][data-schematype="object"], [data-schemapath][data-schematype="array"]');
        sections.forEach(function (section) {
          var path = section.getAttribute('data-schemapath') || '';
          if (path === 'root') return;

          var btn = getSectionToggle(section);
          if (!btn || btn.classList.contains('hb-root-hidden')) return;

          if (isSectionExpanded(section)) {
            try { btn.click(); } catch (e) { /* ignore */ }
          }
        });
      } catch (e) { /* ignore */ }
    }

    // 1) Hide root title and collapse button
    var rootEl = container.querySelector('[data-schemapath="root"]');
    if (rootEl) {
      var rootHeader = rootEl.querySelector(':scope > .je-header');
      if (rootHeader) {
        var titleEl = rootHeader.querySelector('label, span, h3');
        if (titleEl) titleEl.classList.add('hb-root-hidden');
        var rootToggle = rootHeader.querySelector('.json-editor-btntype-toggle');
        if (rootToggle) rootToggle.classList.add('hb-root-hidden');
      }
    }

    function syncBooleanSelectState(selectEl) {
      if (!selectEl) return;
      selectEl.classList.remove('hb-bool-true', 'hb-bool-false');

      var raw = String(selectEl.value || '').trim().toLowerCase();
      if (raw === 'true') {
        selectEl.classList.add('hb-bool-true');
      } else if (raw === 'false') {
        selectEl.classList.add('hb-bool-false');
      }
    }

    function wireBooleanSelect(selectEl) {
      if (!selectEl) return;
      if (selectEl.dataset.hbBoolWired === '1') {
        syncBooleanSelectState(selectEl);
        return;
      }

      selectEl.dataset.hbBoolWired = '1';
      syncBooleanSelectState(selectEl);

      selectEl.addEventListener('change', function () {
        syncBooleanSelectState(selectEl);
      });

      selectEl.addEventListener('input', function () {
        syncBooleanSelectState(selectEl);
      });
    }

    function setupBooleanSelects() {
      try {
        var boolSelects = container.querySelectorAll('[data-schematype="boolean"] select');
        boolSelects.forEach(function (selectEl) {
          wireBooleanSelect(selectEl);
        });
      } catch (e) { /* ignore */ }
    }

    // 2) Build tabs for root-level child objects/arrays
    var childHolder = rootEl
      ? (rootEl.querySelector(':scope > .je-child-editor-holder') || rootEl)
      : container;

    var children = childHolder.querySelectorAll(':scope > [data-schemapath]');
    var objectChildren = [];
    var primitiveChildren = [];

    children.forEach(function (child) {
      var schemaType = child.getAttribute('data-schematype');
      if (schemaType === 'object' || schemaType === 'array') {
        objectChildren.push(child);
      } else {
        primitiveChildren.push(child);
      }
    });

    // Only create tabs if there are object children
    if (objectChildren.length > 0) {
      // Create tabs container
      var tabsWrapper = document.createElement('div');
      tabsWrapper.className = 'hb-tabs-wrapper';

      // Tab bar
      var tabBar = document.createElement('div');
      tabBar.className = 'tabs tabs-boxed bg-base-200 mb-3 inline-flex flex-wrap';
      tabsWrapper.appendChild(tabBar);

      // Tab panels container
      var panelsContainer = document.createElement('div');
      panelsContainer.className = 'hb-tab-panels';
      tabsWrapper.appendChild(panelsContainer);

      objectChildren.forEach(function (child, index) {
        var path = child.getAttribute('data-schemapath') || '';
        var name = path.replace('root.', '');

        // Create tab button
        var tabBtn = document.createElement('button');
        tabBtn.className = 'tab' + (index === 0 ? ' tab-active' : '');
        tabBtn.textContent = name;
        tabBtn.setAttribute('data-hb-tab', name);
        tabBar.appendChild(tabBtn);

        // Create panel
        var panel = document.createElement('div');
        panel.className = 'hb-tab-panel' + (index === 0 ? '' : ' hidden');
        panel.setAttribute('data-hb-panel', name);
        panel.appendChild(child);
        panelsContainer.appendChild(panel);

        // Reflect current expanded state on root child toggle icon
        var toggleBtn = child.querySelector(':scope > .je-header .json-editor-btntype-toggle');
        if (toggleBtn) {
          syncToggleState(toggleBtn);
        }

        // Tab click handler
        tabBtn.addEventListener('click', function () {
          tabBar.querySelectorAll('.tab').forEach(function (t) {
            t.classList.remove('tab-active');
          });
          tabBtn.classList.add('tab-active');
          panelsContainer.querySelectorAll('.hb-tab-panel').forEach(function (p) {
            p.classList.add('hidden');
          });
          var targetPanel = panelsContainer.querySelector('[data-hb-panel="' + name + '"]');
          if (targetPanel) targetPanel.classList.remove('hidden');
        });
      });

      // Insert tabs after primitives
      childHolder.appendChild(tabsWrapper);
    }

    // 3) Force default collapsed state for all object/array sections (except root)
    collapseAllInitially();
    setTimeout(collapseAllInitially, 0);
    setTimeout(collapseAllInitially, 80);

    // 4) Wire toggle buttons for icon state tracking
    var toggleButtons = container.querySelectorAll('.json-editor-btntype-toggle');
    toggleButtons.forEach(function (btn) {
      wireToggleButton(btn);
    });

    setupBooleanSelects();
    setTimeout(setupBooleanSelects, 0);
    setTimeout(setupBooleanSelects, 80);

    // Wire any toggles that may appear later after dynamic rendering.
    if (!container.dataset.hbToggleObserverWired && typeof MutationObserver !== 'undefined') {
      var toggleObserver = new MutationObserver(function () {
        container.querySelectorAll('.json-editor-btntype-toggle').forEach(function (btn) {
          wireToggleButton(btn);
        });
        syncAllToggleStates();
        setupBooleanSelects();
      });
      toggleObserver.observe(container, { childList: true, subtree: true });
      container.dataset.hbToggleObserverWired = '1';
    }

    syncAllToggleStates();



    // Hide field descriptions by default and show them in a popup on hint click.
    // Some JSONEditor layouts render descriptions slightly later, so we run this more than once.
    try {
      var descSelector = '.help-block, .description, p.help, .je-form-input-label + small, label > small, .je-field-description, .je-description, .je-help, small.form-text, p.je-form-input-label[id$="-description"]';
      var activeHintPopup = null;
      var activeHintToggle = null;
      var hintHoverCloseTimer = null;

      function cancelHintHoverClose() {
        if (hintHoverCloseTimer) {
          clearTimeout(hintHoverCloseTimer);
          hintHoverCloseTimer = null;
        }
      }

      function scheduleHintHoverClose() {
        cancelHintHoverClose();
        hintHoverCloseTimer = setTimeout(function () {
          closeHintPopup();
        }, 120);
      }

      function closeHintPopup() {
        cancelHintHoverClose();
        if (activeHintPopup && activeHintPopup.parentNode) {
          activeHintPopup.parentNode.removeChild(activeHintPopup);
        }
        if (activeHintToggle) {
          activeHintToggle.setAttribute('aria-expanded', 'false');
          activeHintToggle.classList.remove('hb-hint-open');
        }
        activeHintPopup = null;
        activeHintToggle = null;
      }

      function openHintPopup(toggle, text) {
        closeHintPopup();

        var popup = document.createElement('div');
        popup.className = 'hb-hint-popover';
        popup.textContent = text;
        var popupHost = toggle.closest('dialog') || document.body;
        popupHost.appendChild(popup);
        popup.addEventListener('mouseenter', cancelHintHoverClose);
        popup.addEventListener('mouseleave', scheduleHintHoverClose);

        var hostRect = popupHost === document.body
          ? { left: 0, top: 0, right: window.innerWidth, bottom: window.innerHeight, width: window.innerWidth, height: window.innerHeight }
          : popupHost.getBoundingClientRect();
        var rect = toggle.getBoundingClientRect();
        var popupRect = popup.getBoundingClientRect();
        var margin = 12;
        var top = rect.bottom + 8;
        var left = rect.left;

        if (left + popupRect.width > hostRect.right - margin) {
          left = Math.max(hostRect.left + margin, hostRect.right - popupRect.width - margin);
        }
        if (top + popupRect.height > hostRect.bottom - margin) {
          top = Math.max(hostRect.top + margin, rect.top - popupRect.height - 8);
        }

        popup.style.left = left + 'px';
        popup.style.top = top + 'px';

        toggle.setAttribute('aria-expanded', 'true');
        // toggle.title = 'Hide hint';
        toggle.classList.add('hb-hint-open');

        activeHintPopup = popup;
        activeHintToggle = toggle;
      }

      function setupHintToggles() {
        var descriptions = container.querySelectorAll(descSelector);
        var created = 0;

        descriptions.forEach(function (desc) {
          if (desc.dataset.hbHintBound === '1') return;

          var hintText = (desc.textContent || '').trim();
          if (!hintText) return;

          desc.style.display = 'none';

          var toggle = document.createElement('button');
          toggle.type = 'button';
          toggle.className = 'hb-hint-toggle';
          toggle.setAttribute('aria-expanded', 'false');
          toggle.innerHTML = '<img src="/images/w98_help_question_mark.avif" alt="Hint" class="w-4 h-4" />';

          toggle.addEventListener('click', function (ev) {
            ev.preventDefault();
            ev.stopPropagation();
            if (activeHintToggle === toggle) {
              closeHintPopup();
            } else {
              openHintPopup(toggle, hintText);
            }
          });
          toggle.addEventListener('mouseenter', function () {
            cancelHintHoverClose();
            if (activeHintToggle !== toggle) {
              openHintPopup(toggle, hintText);
            }
          });
          toggle.addEventListener('mouseleave', function () {
            scheduleHintHoverClose();
          });

          try {
            if (desc.parentNode) {
              var checkboxLabel = null;
              try {
                checkboxLabel = desc.parentNode.querySelector(':scope > .hb-checkbox-label');
              } catch (e) { /* ignore */ }

              if (checkboxLabel) {
                toggle.classList.add('hb-hint-inline');
                checkboxLabel.insertAdjacentElement('afterend', toggle);
              } else {
                desc.parentNode.insertBefore(toggle, desc);
              }

              desc.dataset.hbHintBound = '1';
              created++;
            }
          } catch (e) { /* ignore */ }
        });

        if (window.console && typeof window.console.debug === 'function') {
          console.debug('HBJsonEditor: found descriptions:', descriptions.length, 'created toggles:', created);
        }
      }

      if (!container.dataset.hbHintGlobalWired) {
        document.addEventListener('click', function (ev) {
          if (!activeHintPopup) return;
          var target = ev.target;
          if (activeHintPopup.contains(target)) return;
          if (activeHintToggle && activeHintToggle.contains(target)) return;
          closeHintPopup();
        });

        document.addEventListener('keydown', function (ev) {
          if (ev.key === 'Escape') closeHintPopup();
        });

        container.dataset.hbHintGlobalWired = '1';
      }

      setupHintToggles();
      setTimeout(setupHintToggles, 0);
      setTimeout(setupHintToggles, 80);
      if (typeof requestAnimationFrame === 'function') requestAnimationFrame(setupHintToggles);

      if (!container.dataset.hbHintObserverWired && typeof MutationObserver !== 'undefined') {
        var obs = new MutationObserver(function () {
          setupHintToggles();
        });
        obs.observe(container, { childList: true, subtree: true });
        container.dataset.hbHintObserverWired = '1';
      }
    } catch (e) { /* ignore */ }
  }

  function mount(options) {
    if (!window.JSONEditor) throw new Error('window.JSONEditor is not loaded');

    function coerceBooleanLeaf(rawValue) {
      if (typeof rawValue === 'boolean') return rawValue;
      if (typeof rawValue === 'string') {
        var normalized = rawValue.trim().toLowerCase();
        if (normalized === '') return false;
        if (normalized === 'true' || normalized === '1') return true;
        if (normalized === 'false' || normalized === '0') return false;
        if (normalized === 'yes' || normalized === 'on') return true;
        if (normalized === 'no' || normalized === 'off') return false;
      }
      if (rawValue === 1) return true;
      if (rawValue === 0) return false;
      return rawValue;
    }

    function coerceValuesBySchema(currentValue, currentSchema) {
      if (!currentSchema) return currentValue;

      if (currentSchema.type === 'boolean') {
        return coerceBooleanLeaf(currentValue);
      }

      if (schemaHasType(currentSchema, 'object') && currentSchema.properties && currentValue && typeof currentValue === 'object' && !Array.isArray(currentValue)) {
        Object.keys(currentSchema.properties).forEach(function (propName) {
          if (!Object.prototype.hasOwnProperty.call(currentValue, propName)) return;
          currentValue[propName] = coerceValuesBySchema(currentValue[propName], currentSchema.properties[propName]);
        });
        return currentValue;
      }

      if (schemaHasType(currentSchema, 'array') && Array.isArray(currentValue) && currentSchema.items) {
        for (var i = 0; i < currentValue.length; i++) {
          currentValue[i] = coerceValuesBySchema(currentValue[i], currentSchema.items);
        }
        return currentValue;
      }

      return currentValue;
    }

    function isIntegerPathSegment(segment) {
      return /^\d+$/.test(segment || '');
    }

    function setBySchemaPath(targetValue, schemaPath, nextValue) {
      if (!targetValue || typeof targetValue !== 'object') return;
      if (!schemaPath) return;

      var parts = String(schemaPath).split('.');
      if (parts[0] === 'root') {
        parts = parts.slice(1);
      }
      if (parts.length === 0) return;

      var cursor = targetValue;
      for (var i = 0; i < parts.length - 1; i++) {
        var part = parts[i];
        var nextPart = parts[i + 1];

        // Раздел со значением null (у поля ['object', 'null'] выбран null) не воссоздаём из полей скрытого объектного варианта
        if (Array.isArray(cursor)) {
          var arrIndex = parseInt(part, 10);
          if (!Number.isFinite(arrIndex) || arrIndex < 0) return;
          if (cursor[arrIndex] === null) return;
          if (cursor[arrIndex] === undefined) {
            cursor[arrIndex] = isIntegerPathSegment(nextPart) ? [] : {};
          }
          cursor = cursor[arrIndex];
          continue;
        }

        if (cursor[part] === null) return;
        if (cursor[part] === undefined) {
          cursor[part] = isIntegerPathSegment(nextPart) ? [] : {};
        }
        cursor = cursor[part];
        if (cursor === undefined || cursor === null) return;
      }

      var lastPart = parts[parts.length - 1];
      if (Array.isArray(cursor)) {
        var lastIndex = parseInt(lastPart, 10);
        if (!Number.isFinite(lastIndex) || lastIndex < 0) return;
        cursor[lastIndex] = nextValue;
      } else {
        cursor[lastPart] = nextValue;
      }
    }

    function readSelectBooleanValue(selectEl) {
      if (!selectEl) return undefined;

      var candidate = coerceBooleanLeaf(selectEl.value);
      if (typeof candidate === 'boolean') return candidate;

      var selectedOption = null;
      try {
        selectedOption = selectEl.options && selectEl.selectedIndex >= 0
          ? selectEl.options[selectEl.selectedIndex]
          : null;
      } catch (e) { /* ignore */ }

      if (selectedOption) {
        var fromOptionValue = coerceBooleanLeaf(selectedOption.value);
        if (typeof fromOptionValue === 'boolean') return fromOptionValue;

        var fromOptionText = coerceBooleanLeaf((selectedOption.textContent || '').trim());
        if (typeof fromOptionText === 'boolean') return fromOptionText;
      }

      return undefined;
    }

    function applyDomBooleanOverrides(payloadValue) {
      if (!payloadValue || typeof payloadValue !== 'object') return payloadValue;

      try {
        var boolHolders = container.querySelectorAll('[data-schematype="boolean"][data-schemapath]');
        boolHolders.forEach(function (holder) {
          var selectEl = holder.querySelector('select');
          if (!selectEl) return;

          var boolValue = readSelectBooleanValue(selectEl);
          if (typeof boolValue !== 'boolean') return;

          var schemaPath = holder.getAttribute('data-schemapath') || '';
          setBySchemaPath(payloadValue, schemaPath, boolValue);
        });
      } catch (e) { /* ignore */ }

      return payloadValue;
    }



    var opts = options || {};
    var container = document.getElementById(opts.containerId);
    var applyButton = document.getElementById(opts.applyButtonId);
    var editor = null;

    if (!container) throw new Error('Container not found: ' + opts.containerId);
    if (!applyButton) throw new Error('Button not found: ' + opts.applyButtonId);

    container.classList.add('hb-json-editor');
    applyButton.disabled = true;

    var value = getInitialValue(opts);
    var schema = opts.schema || inferSchema(value);

    function forEachSchemaTarget(schemaObj, key, visitor) {
      if (!schemaObj || !key || typeof visitor !== 'function') return;

      if (key.indexOf('.') !== -1) {
        var parts = key.split('.');
        var target = schemaObj;
        for (var i = 0; i < parts.length; i++) {
          // массив в пути (accounts.close_by_margin.profit) — переходим к схеме элемента
          if (schemaHasType(target, 'array')) target = target.items;
          if (!target || !schemaHasType(target, 'object') || !target.properties) {
            target = null;
            break;
          }
          target = target.properties[parts[i]];
        }
        if (target) visitor(target, parts[parts.length - 1]);
        return;
      }

      (function walk(s) {
        if (!s) return;
        if (schemaHasType(s, 'object') && s.properties) {
          if (s.properties[key]) visitor(s.properties[key], key);
          Object.keys(s.properties).forEach(function (propName) {
            walk(s.properties[propName]);
          });
        } else if (schemaHasType(s, 'array') && s.items) {
          walk(s.items);
        }
      })(schemaObj);
    }

    function applyCommentsToSchema(schemaObj, comments) {
      if (!schemaObj || !comments) return;

      // Set description by dotted path or by name (apply everywhere)
      Object.keys(comments).forEach(function (key) {
        var comment = comments[key];
        if (!comment) return;

        forEachSchemaTarget(schemaObj, key, function (target) {
          target.description = comment;
        });
      });
    }

    function applySchemaPatchToSchema(schemaObj, schemaPatch) {
      if (!schemaObj || !schemaPatch) return;

      Object.keys(schemaPatch).forEach(function (key) {
        var rules = schemaPatch[key];
        if (!rules || typeof rules !== 'object') return;

        forEachSchemaTarget(schemaObj, key, function (target) {
          Object.keys(rules).forEach(function (ruleKey) {
            var ruleValue = rules[ruleKey];

            if (ruleKey === 'required' || ruleValue === undefined) return;
            target[ruleKey] = ruleValue;
          });

          if (rules.required === true) {
            target.required = true;
          }
        });
      });
    }

    function createEditorWithSchema(finalSchema) {
      value = coerceValuesBySchema(value, finalSchema);

      editor = new window.JSONEditor(container, {
        schema: finalSchema,
        startval: value,
        theme: 'html',
        disable_edit_json: true,
        disable_properties: true,
        show_errors: 'always',
        remove_button_labels: true,
        collapsed: true,
        array_controls_top: true
      });

      postInit(container, editor);
      // Доступ к редактору для внешних компонентов (мастер parameter_mining): mount() асинхронный и не всегда успевает вернуть editor
      container.hbEditor = editor;
      applyButton.disabled = false;
      return editor;
    }

    // Узел схемы по пути a.b.c; массивы проходятся через items (settings[] → схема одного элемента)
    function schemaAt(schemaObj, path) {
      var node = schemaObj;
      var parts = path ? path.split('.') : [];
      for (var i = 0; i < parts.length && node; i++) {
        if (schemaHasType(node, 'array')) node = node.items;
        node = node && schemaHasType(node, 'object') && node.properties ? node.properties[parts[i]] : null;
      }
      if (schemaHasType(node, 'array')) node = node.items;
      return node;
    }

    if (opts.paramCommentsScoped) {
      // { 'tester_config': url, 'settings': url } — подсказки каждого файла применяются только внутри своего раздела
      var scopePaths = Object.keys(opts.paramCommentsScoped);
      Promise.all(scopePaths.map(function (path) {
        return fetch(opts.paramCommentsScoped[path], { cache: 'no-store' })
          .then(function (r) { return r.ok ? r.json() : {}; })
          .catch(function () { return {}; });
      })).then(function (commentsList) {
        // paramComments здесь — подсказки к самим разделам (верхний уровень)
        if (opts.paramComments) {
          try { applyCommentsToSchema(schema, opts.paramComments); } catch (e) { /* ignore */ }
        }
        scopePaths.forEach(function (path, i) {
          try { applyCommentsToSchema(schemaAt(schema, path), commentsList[i]); } catch (e) { /* ignore */ }
        });
        if (opts.paramSchemaPatch) {
          try { applySchemaPatchToSchema(schema, opts.paramSchemaPatch); } catch (e) { /* ignore */ }
        }
        createEditorWithSchema(schema);
      });
    } else if (opts.paramCommentsUrl) {
      fetch(opts.paramCommentsUrl, { cache: 'no-store' })
        .then(function (r) { return r.ok ? r.json() : {}; })
        .then(function (comments) {
          try { applyCommentsToSchema(schema, comments); } catch (e) { /* ignore */ }
          if (opts.paramSchemaPatch) {
            try { applySchemaPatchToSchema(schema, opts.paramSchemaPatch); } catch (e) { /* ignore */ }
          }
          if (opts.paramValidation) {
            try { applySchemaPatchToSchema(schema, opts.paramValidation); } catch (e) { /* ignore */ }
          }
          createEditorWithSchema(schema);
        })
        .catch(function () {
          if (opts.paramSchemaPatch) {
            try { applySchemaPatchToSchema(schema, opts.paramSchemaPatch); } catch (e) { /* ignore */ }
          }
          if (opts.paramValidation) {
            try { applySchemaPatchToSchema(schema, opts.paramValidation); } catch (e) { /* ignore */ }
          }
          createEditorWithSchema(schema);
        });
    } else {
      if (opts.paramComments) {
        try { applyCommentsToSchema(schema, opts.paramComments); } catch (e) { /* ignore */ }
      }
      if (opts.paramSchemaPatch) {
        try { applySchemaPatchToSchema(schema, opts.paramSchemaPatch); } catch (e) { /* ignore */ }
      }
      if (opts.paramValidation) {
        try { applySchemaPatchToSchema(schema, opts.paramValidation); } catch (e) { /* ignore */ }
      }
      createEditorWithSchema(schema);
    }

    applyButton.addEventListener('click', function () {
      if (applyButton.disabled) {
        return;
      }

      if (!editor) {
        if (typeof window.showErrorToast === 'function') {
          window.showErrorToast('Editor is not ready yet.');
        }
        return;
      }

      var validationErrors = [];
      try {
        validationErrors = editor.validate() || [];
      } catch (e) {
        validationErrors = [];
      }

      if (validationErrors.length > 0) {
        if (typeof window.showErrorToast === 'function') {
          window.showErrorToast(opts.validationMessage || 'Please fix validation errors before applying.');
        }
        return;
      }

      var payloadValue = editor.getValue();
      payloadValue = applyDomBooleanOverrides(payloadValue);
      payloadValue = coerceValuesBySchema(payloadValue, schema);
      var requestBody = JSON.stringify(payloadValue);

      if (typeof opts.buildRequestBody === 'function') {
        requestBody = opts.buildRequestBody(payloadValue);
      }

      applyButton.disabled = true;
      fetch(opts.applyUrl, {
        method: opts.method || 'POST',
        headers: opts.headers || { 'Content-Type': 'application/json' },
        body: requestBody
      })
        .then(function (response) {
          return response.text().then(function (bodyText) {
            return { ok: response.ok, text: bodyText };
          });
        })
        .then(function (result) {
          appendToastFromHtml(result.text);
          if (typeof opts.onResponse === 'function') {
            opts.onResponse(result);
          }
          if (!result.ok && typeof window.showErrorToast === 'function') {
            window.showErrorToast(opts.errorMessage || 'Failed to apply changes.');
          }
          if (result.ok && typeof opts.onSuccess === 'function') {
            opts.onSuccess(result);
          }
        })
        .catch(function (err) {
          if (typeof window.showErrorToast === 'function') {
            window.showErrorToast(opts.requestFailedMessage || 'Request failed.');
          }
          if (typeof opts.onError === 'function') {
            opts.onError(err);
          }
        })
        .finally(function () {
          applyButton.disabled = false;
        });
    });

    return editor;
  }

  window.HBJsonEditor = {
    mount: mount,
    inferSchema: inferSchema,
    decodeBase64Utf8: decodeBase64Utf8
  };
})();
