﻿var dict = {};

function showJEditor(id, json) {
    var myjson = json;
    dict["" + id] = myjson;
    var opt = {
        change: function (data) {
            myjson = data;
            dict["" + id] = data;
        },
        propertyclick: function (path) {}
    };
/*    opt.propertyElement = $('#b' + id);*/
    $('#' + id).jsonEditor(myjson, opt);

    $('#b' + id).click(function () {
        /*document.getElementById('ttt').innerHTML = JSON.stringify(dict["" + id]);*/

        //var xhr = new XMLHttpRequest();
        //xhr.open("POST", window.location.origin + "/update/settings", true);
        //xhr.setRequestHeader('Content-Type', 'application/json');
        //xhr.send(JSON.stringify(dict["" + id]));
        //window.location.href = "/";

        $.post("update/settings", JSON.stringify(dict["" + id]))
            .done(function (result) {
                window.location.href = "/";
            });
    });

    /*document.getElementById(id).innerHTML = document.getElementById(id).innerHTML.replace('title="account"', 'title="тут вписать ссылку на API"');*/
}

var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
    coll[i].addEventListener("click", function () {
        this.classList.toggle("active");
        var content = this.nextElementSibling;
        if (content.style.display === "block") {
            content.style.display = "none";
        } else {
            content.style.display = "block";
        }
    });
}

var acc = document.getElementsByClassName("infohint");
var i;

for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function () {
        /* Toggle between adding and removing the "active" class,
        to highlight the button that controls the panel */
        this.classList.toggle("active");

        /* Toggle between hiding and showing the active panel */
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
            panel.style.display = "none";
        } else {
            panel.style.display = "block";
        }
    });
}