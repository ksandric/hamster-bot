@echo off
setlocal
cd /d "%~dp0"

set EXE_PATH=hb_c.exe

if not exist "%EXE_PATH%" (
    echo.
    echo Compiled executable not found: "%EXE_PATH%"
    echo Build Release win-x64 first.
    exit /b 1
)

echo Downloading tester data...
"%EXE_PATH%" --download-data

if errorlevel 1 (
    echo.
    echo Download failed with exit code %errorlevel%.
    exit /b %errorlevel%
)

echo.
echo Download finished.
pause
exit /b 0
