@echo off
setlocal

rem Opens an inbound TCP port in Windows Firewall. Requires administrator rights.
net session >nul 2>&1
if errorlevel 1 (
    echo Requesting administrator rights...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b 0
)

:ask
set "PORT="
set /p "PORT=Enter TCP port to open (1-65535): "
if not defined PORT goto ask
echo %PORT%| findstr /r "^[0-9][0-9]*$" >nul
if errorlevel 1 (
    echo Invalid port: "%PORT%"
    goto ask
)
if %PORT% LSS 1 (
    echo Port must be between 1 and 65535.
    goto ask
)
if %PORT% GTR 65535 (
    echo Port must be between 1 and 65535.
    goto ask
)

set "RULE_NAME=Open TCP %PORT%"

netsh advfirewall firewall show rule name="%RULE_NAME%" >nul 2>&1
if not errorlevel 1 (
    echo Rule "%RULE_NAME%" already exists.
    pause
    exit /b 0
)

netsh advfirewall firewall add rule name="%RULE_NAME%" dir=in action=allow protocol=TCP localport=%PORT% profile=any
if errorlevel 1 (
    echo.
    echo Failed to open TCP port %PORT%.
    pause
    exit /b 1
)

echo.
echo TCP port %PORT% is open (rule "%RULE_NAME%").
pause
exit /b 0
