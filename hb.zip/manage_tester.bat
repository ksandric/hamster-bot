@echo off
setlocal
rem Tester tools: run the tester, optimize a report, download and convert historical data.
rem
rem USAGE
rem   manage_tester.bat                      - menu
rem   manage_tester.bat tester               - run the tester
rem   manage_tester.bat optimizer [folder]   - optimize a report (default folder: tester\report)
rem   manage_tester.bat download             - download historical data
rem   manage_tester.bat convert              - convert data (*_1m.csv to Parquet)
rem   A report folder can also be dragged onto this file to optimize it.
cd /d "%~dp0"

set "EXE_PATH=%~dp0hb_c.exe"

if not exist "%EXE_PATH%" (
    echo.
    echo Compiled executable not found: "%EXE_PATH%"
    echo Build Release win-x64 first.
    pause
    exit /b 1
)

if "%~1"=="" goto :menu
if exist "%~1\" (
    call :exec "Report optimizer" --run-report-optimizer "%~1"
) else (
    call :run "%~1" "%~2"
)
set "RC=%errorlevel%"
pause
exit /b %RC%

:menu
echo.
echo ========================================
echo hamster-bot tester
echo ========================================
echo   1. Run tester
echo   2. Optimize report
echo   3. Download historical data
echo   4. Convert data (*_1m.csv to Parquet)
echo   0. Exit
set "CHOICE="
set /p "CHOICE=Choose an action: "
rem Empty input (Enter or end of input) also exits, otherwise the menu would loop forever without input
if not defined CHOICE exit /b 0
if "%CHOICE%"=="0" exit /b 0
if "%CHOICE%"=="1" (
    call :run tester
    goto :menu
)
if "%CHOICE%"=="2" (
    set "REPORT_DIR="
    set /p "REPORT_DIR=Report folder [tester\report]: "
    call :run optimizer "%%REPORT_DIR%%"
    goto :menu
)
if "%CHOICE%"=="3" (
    call :run download
    goto :menu
)
if "%CHOICE%"=="4" (
    call :run convert
    goto :menu
)
echo Invalid choice
goto :menu

rem :run  1=action  2=report folder (optimizer only)
:run
if /i "%~1"=="tester" goto :act_tester
if /i "%~1"=="optimizer" goto :act_optimizer
if /i "%~1"=="download" goto :act_download
if /i "%~1"=="convert" goto :act_convert
echo Unknown action "%~1". Use: tester, optimizer [folder], download, convert
exit /b 1

:act_tester
call :exec "Tester" --run-tester
exit /b

:act_optimizer
set "REPORT_DIR=%~2"
if "%REPORT_DIR%"=="" set "REPORT_DIR=tester\report"
call :exec "Report optimizer" --run-report-optimizer "%REPORT_DIR%"
exit /b

:act_download
call :exec "Download" --download-data
exit /b

:act_convert
call :exec "Conversion" --convert-data
exit /b

rem :exec  1=action name  2,3=hb_c.exe arguments
:exec
echo.
echo %~1 started...
"%EXE_PATH%" %2 %3
set "RC=%errorlevel%"
echo.
if not "%RC%"=="0" (
    echo %~1 failed with exit code %RC%.
) else (
    echo %~1 finished.
)
exit /b %RC%
