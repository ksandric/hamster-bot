@echo off
setlocal
cd /d "%~dp0"

set EXE_PATH=hb_c.exe

if not exist "%EXE_PATH%" (
    echo.
    echo Compiled executable not found: "%EXE_PATH%"
    echo Build Release win-x64 first.
    exit /b 1
)

echo Running tester...
"%EXE_PATH%" --run-tester

if errorlevel 1 (
    echo.
    echo Tester failed with exit code %errorlevel%.
    exit /b %errorlevel%
)

echo.
echo Tester finished.
pause
exit /b 0
