@echo off
setlocal
cd /d "%~dp0"

set EXE_PATH=hb_c.exe

if not exist "%EXE_PATH%" (
    echo.
    echo Compiled executable not found: "%EXE_PATH%"
    echo Build Release win-x64 first.
    pause
    exit /b 1
)

set REPORT_DIR=tester\report
if not "%~1"=="" set REPORT_DIR=%~1

echo Running report optimizer for "%REPORT_DIR%"...
"%EXE_PATH%" --run-report-optimizer "%REPORT_DIR%"

if errorlevel 1 (
    echo.
    echo Report optimizer failed with exit code %errorlevel%.
    pause
    exit /b %errorlevel%
)

echo.
echo Report optimizer finished.
pause
exit /b 0
