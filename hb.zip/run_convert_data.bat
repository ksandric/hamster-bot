@echo off
setlocal
cd /d "%~dp0"

set EXE_PATH=%~dp0hb_c.exe

if not exist "%EXE_PATH%" (
    echo.
    echo Compiled executable not found: "%EXE_PATH%"
    echo Build Release win-x64 first.
    exit /b 1
)

echo Converting tester data (*_1m.csv to Parquet)...
"%EXE_PATH%" --convert-data

if errorlevel 1 (
    echo.
    echo Conversion finished with errors, exit code %errorlevel%.
    pause
    exit /b 1
)

echo.
echo Conversion finished.
pause
exit /b 0
