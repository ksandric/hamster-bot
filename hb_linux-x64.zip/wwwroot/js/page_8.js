﻿var dict = {};

function showJEditor(id, json) {
    var myjson = json;
    dict["" + id] = myjson;
    var opt = {
        change: function (data) {
            myjson = data;
            dict["" + id] = data;
        },
        propertyclick: function (path) {}
    };
/*    opt.propertyElement = $('#b' + id);*/
    $('#' + id).jsonEditor(myjson, opt);

    $('#b' + id).click(function () {
        /*document.getElementById('ttt').innerHTML = JSON.stringify(dict["" + id]);*/

        //var xhr = new XMLHttpRequest();
        //xhr.open("POST", window.location.origin + "/update/settings", true);
        //xhr.setRequestHeader('Content-Type', 'application/json');
        //xhr.send(JSON.stringify(dict["" + id]));
        //window.location.href = "/";

        $.post("update/settings", JSON.stringify(dict["" + id]))
            .done(function (result) {
                window.location.href = "/";
            });
    });


    $('#config' + id).click(function () {
        $.post("update/config", JSON.stringify(dict["" + id]))
            .done(function (result) {
                window.location.href = "/";
            });
    });

    $('#config_tester' + id).click(function () {
        $.post("update/config/tester", JSON.stringify(dict["" + id]))
            .done(function (result) {
                window.location.href = "/";
            });
    });

    $('#api' + id).click(function () {
        $.post("update/api", JSON.stringify(dict["" + id]))
            .done(function (result) {
                window.location.href = "/";
            });
    });

    /*document.getElementById(id).innerHTML = document.getElementById(id).innerHTML.replace('title="account"', 'title="тут вписать ссылку на API"');*/
}

var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
    coll[i].addEventListener("click", function () {
        this.classList.toggle("active");
        var content = this.nextElementSibling;
        if (content.style.display === "block") {
            content.style.display = "none";
        } else {
            content.style.display = "block";
        }
    });
}

var acc = document.getElementsByClassName("infohint");
var i;

for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function () {
        /* Toggle between adding and removing the "active" class,
        to highlight the button that controls the panel */
        this.classList.toggle("active");

        /* Toggle between hiding and showing the active panel */
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
            panel.style.display = "none";
        } else {
            panel.style.display = "block";
        }
    });
}

function toggleAllAccordions() {
    var button = document.getElementById("collapseAll");
    var accordionHeaders = document.querySelectorAll(".accordion-header button");
    var accordionCollapses = document.querySelectorAll(".accordion-collapse");

    var isCollapsed = Array.from(accordionHeaders).some(function (header) {
        return !header.classList.contains("collapsed");
    });

    if (isCollapsed) {
        button.innerHTML = "Expand all";
        accordionHeaders.forEach(function (header) {
            header.classList.add("collapsed");
        });
        accordionCollapses.forEach(function (collapse) {
            collapse.classList.remove("show");
        });
    } else {
        button.innerHTML = "Collaps all";
        accordionHeaders.forEach(function (header) {
            header.classList.remove("collapsed");
        });
        accordionCollapses.forEach(function (collapse) {
            collapse.classList.add("show");
        });
    }
}

function sortTable(n) {
    const table = document.getElementById('dataTable');
    let switching = true;
    let dir = 'asc';
    let switchcount = 0;
    while (switching) {
        switching = false;
        const rows = table.rows;
        for (let i = 1; i < rows.length - 1; i++) {
            let shouldSwitch = false;
            const x = rows[i].getElementsByTagName('TD')[n];
            const y = rows[i + 1].getElementsByTagName('TD')[n];
            if (!x || !y) continue;

            const xContent = x.innerText || '';
            const yContent = y.innerText || '';
            const xNum = parseFloat(xContent.replace(',', '.'));
            const yNum = parseFloat(yContent.replace(',', '.'));

            if (!isNaN(xNum) && !isNaN(yNum)) {
                if ((dir === 'asc' && xNum > yNum) || (dir === 'desc' && xNum < yNum)) {
                    shouldSwitch = true;
                }
            } else {
                if ((dir === 'asc' && xContent.toLowerCase() > yContent.toLowerCase()) ||
                    (dir === 'desc' && xContent.toLowerCase() < yContent.toLowerCase())) {
                    shouldSwitch = true;
                }
            }

            if (shouldSwitch) {
                rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
                switching = true;
                switchcount++;
                break;
            }
        }

        if (!switching && switchcount === 0 && dir === 'asc') {
            dir = 'desc';
            switching = true;
        }
    }
}

function toggleColumn(colIndex) {
    const table = document.getElementById('dataTable');
    for (let i = 0; i < table.rows.length; i++) {
        const cell = table.rows[i].cells[colIndex];
        if (cell) {
            cell.style.display = (cell.style.display === 'none') ? '' : 'none';
        }
    }
}