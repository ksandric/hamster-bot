// Тема «Neon Arcade»: сцена-синтвейв, кинескоп и искры от нажатий.
// Работает только пока на <html> стоит data-theme="neon-arcade"; при смене темы всё
// созданное здесь убирается. Оформление — блок neon-arcade в htmx_4.css.
// Звуки общие для всех тем (ui-sounds.js); отсюда проигрывается только звук включения.
(function () {
  'use strict';

  var THEME = 'neon-arcade';
  var POWERON_KEY = 'hbArcadePowerOn';
  var FONTS_URL = 'https://fonts.googleapis.com/css2?family=Orbitron:wght@600;800&family=VT323&display=swap';
  var root = document.documentElement;
  var reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  var active = false;
  var fx = null, crt = null, sparks = null;

  function playSound(name) {
    if (window.hbSound) window.hbSound.play(name);
  }

  // ── Искры ──────────────────────────────────────────────────────────
  var SPARK_COLORS = ['oklch(85% 0.15 200)', 'oklch(68% 0.28 345)', 'oklch(86% 0.17 85)', '#ffffff'];

  function burst(x, y, count) {
    if (!sparks || reducedMotion || !sparks.animate) return;
    for (var i = 0; i < count; i++) {
      var s = document.createElement('i');
      var c = SPARK_COLORS[i % SPARK_COLORS.length];
      s.style.left = x + 'px';
      s.style.top = y + 'px';
      s.style.background = c;
      s.style.boxShadow = '0 0 6px ' + c;
      sparks.appendChild(s);
      var ang = Math.random() * Math.PI * 2;
      var dist = 24 + Math.random() * 46;
      var dx = Math.cos(ang) * dist;
      var dy = Math.sin(ang) * dist - 10;
      var anim = s.animate([
        { transform: 'translate(-50%,-50%) scale(1)', opacity: 1 },
        { transform: 'translate(calc(-50% + ' + dx + 'px), calc(-50% + ' + (dy + 26) + 'px)) scale(0.3)', opacity: 0 }
      ], { duration: 420 + Math.random() * 260, easing: 'cubic-bezier(0.2, 0.7, 0.4, 1)' });
      anim.onfinish = (function (el) { return function () { el.remove(); }; })(s);
    }
  }

  // ── Сцена ──────────────────────────────────────────────────────────
  function el(tag, attrs, html) {
    var n = document.createElement(tag);
    for (var k in attrs) n.setAttribute(k, attrs[k]);
    if (html) n.innerHTML = html;
    return n;
  }

  function loadFonts() {
    if (document.getElementById('na-fonts')) return;
    document.head.appendChild(el('link', { id: 'na-fonts', rel: 'stylesheet', href: FONTS_URL }));
  }

  function mount() {
    if (fx) return;
    loadFonts();
    fx = el('div', { id: 'na-fx', 'aria-hidden': 'true' },
      '<div class="na-stars"></div><div class="na-shooting"></div>' +
      '<div class="na-sun-glow"></div><div class="na-sun"></div>' +
      '<div class="na-mountains"></div>' +
      '<div class="na-floor"><div class="na-grid"></div></div>');
    crt = el('div', { id: 'na-crt', 'aria-hidden': 'true' });
    sparks = el('div', { id: 'na-sparks', 'aria-hidden': 'true' });
    document.body.insertBefore(fx, document.body.firstChild);
    document.body.appendChild(crt);
    document.body.appendChild(sparks);
  }

  function unmount() {
    [fx, crt, sparks].forEach(function (n) { if (n) n.remove(); });
    fx = crt = sparks = null;
    root.classList.remove('na-poweron');
  }

  // Включение кинескопа: при выборе темы и один раз за сессию при загрузке
  function powerOn(withSound) {
    if (withSound) playSound('boot');
    if (reducedMotion) return;
    root.classList.remove('na-poweron');
    void root.offsetWidth; // перезапуск анимации
    root.classList.add('na-poweron');
    setTimeout(function () { root.classList.remove('na-poweron'); }, 950);
  }

  function sync(fromUserSwitch) {
    var want = root.getAttribute('data-theme') === THEME;
    if (want === active) return;
    active = want;
    if (active) {
      mount();
      if (fromUserSwitch) {
        powerOn(true);
      } else {
        var seen = false;
        try { seen = sessionStorage.getItem(POWERON_KEY) === '1'; sessionStorage.setItem(POWERON_KEY, '1'); } catch (e) { }
        if (!seen) powerOn(false);
      }
    } else {
      unmount();
    }
  }

  // Искры от нажатий
  document.addEventListener('pointerdown', function (e) {
    if (!active || !e.isTrusted) return;
    var t = e.target instanceof Element ? e.target : null;
    if (!t) return;
    var hit = t.closest('.btn, .tab, .bt-pause-btn, .bt-icon-btn, .bt-symbol-btn, #hb-promo-launcher');
    if (hit && !hit.disabled) {
      burst(e.clientX, e.clientY, hit.classList.contains('btn-primary') ? 16 : 10);
    }
  }, true);

  // Тема меняется атрибутом data-theme (initTheme в htmx_4.js)
  if (window.MutationObserver) {
    new MutationObserver(function () { sync(true); })
      .observe(root, { attributes: true, attributeFilter: ['data-theme'] });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { sync(false); });
  else sync(false);
})();
