// Живой лог: строки приходят по одной через SSE (/log/stream, /htmx/log/stream) и дописываются в конец.
// Положение прокрутки не сбивается; если прокрутка у нижнего края — лог сам прокручивается к новым строкам.
// Используется страницей /log и вкладкой Log (log-panel.html)
(function () {
  if (window.HbLogStream) return;

  var BOTTOM_GAP = 40;  // ближе этого к нижнему краю (px) — «у нижнего края», автопрокрутка включена
  var active = {};      // открытые потоки по ключу: новая вкладка Log закрывает поток прежней

  // opts: url — адрес потока; box — куда дописывать строки; scroller — что прокручивается (по умолчанию box);
  // key — один поток на ключ; maxLines — сколько строк держать; render(text, lineElement) — вывод строки;
  // paused — не подключаться сразу. Возвращает { pause(), resume(), isPaused(), close() }
  function attach(opts) {
    var box = opts.box;
    var scroller = opts.scroller || box;
    var scrollEvents = scroller === document.scrollingElement ? window : scroller;
    var maxLines = opts.maxLines || 2000;
    var render = opts.render || function (text, el) { el.textContent = text; };
    var key = opts.key || opts.url;

    if (active[key]) active[key].close();

    var source = null;
    var lastId = '';
    var queue = [];        // строки, ещё не выведенные (выводятся пачкой раз в кадр)
    var clearPending = false;
    var frame = 0;
    var closed = false;
    var stuck = true;      // прокрутка у нижнего края

    // Положение запоминается при прокрутке, а не перед выводом: иначе строка, пришедшая во время
    // прокрутки колесом вниз, могла бы «перескочить» разрыв и включить автопрокрутку раньше времени
    function atBottom() {
      return scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight < BOTTOM_GAP;
    }
    function onScroll() { stuck = atBottom(); }
    scrollEvents.addEventListener('scroll', onScroll, { passive: true });

    function flush() {
      frame = 0;
      if (closed || !box.isConnected) { close(); return; }
      if (clearPending) {
        box.textContent = '';
        clearPending = false;
      }
      if (queue.length) {
        var fragment = document.createDocumentFragment();
        for (var i = 0; i < queue.length; i++) {
          var el = document.createElement('div');
          render(queue[i], el);
          fragment.appendChild(el);
        }
        queue = [];
        box.appendChild(fragment);
      }
      // Лишние строки сверху: при прокрутке не у края сдвиг компенсируется, чтобы видимое не уехало
      var extra = box.childElementCount - maxLines;
      if (extra > 0) {
        var before = scroller.scrollHeight;
        while (extra-- > 0) box.removeChild(box.firstElementChild);
        if (!stuck) scroller.scrollTop -= before - scroller.scrollHeight;
      }
      if (stuck) scroller.scrollTop = scroller.scrollHeight;
    }
    function schedule() {
      if (!frame) frame = requestAnimationFrame(flush);
    }
    function push(text, reset) {
      if (reset) {
        queue = [];
        clearPending = true;
      }
      if (text !== null) {
        // Фоновая вкладка не рисует кадры: очередь не растёт больше, чем будет показано
        if (queue.length >= maxLines) queue.shift();
        queue.push(text);
      }
      schedule();
    }
    function onEvent(reset, e) {
      if (!box.isConnected) { close(); return; }
      if (e.lastEventId) lastId = e.lastEventId;
      push(e.type === 'clear' ? null : e.data, reset);
    }

    function connect() {
      if (source || closed) return;
      // После паузы — только пропущенные строки; если они уже вытеснены, сервер пришлёт весь буфер
      source = new EventSource(opts.url + (lastId ? (opts.url.indexOf('?') < 0 ? '?' : '&') + 'after=' + encodeURIComponent(lastId) : ''));
      source.addEventListener('message', function (e) { onEvent(false, e); });
      source.addEventListener('reset', function (e) { onEvent(true, e); });
      source.addEventListener('clear', function (e) { onEvent(true, e); });
    }
    function disconnect() {
      if (source) { source.close(); source = null; }
    }
    function close() {
      closed = true;
      disconnect();
      if (frame) { cancelAnimationFrame(frame); frame = 0; }
      scrollEvents.removeEventListener('scroll', onScroll);
      if (active[key] === handle) delete active[key];
    }

    var handle = {
      pause: disconnect,
      resume: connect,
      isPaused: function () { return !source; },
      close: close
    };
    active[key] = handle;
    // htmx убирает вкладку при переходе в другой раздел
    box.addEventListener('htmx:beforeCleanupElement', function (e) { if (e.target === box) close(); });
    if (!opts.paused) connect();
    return handle;
  }

  window.HbLogStream = { attach: attach };
})();
