// HTMX dashboard JavaScript
var THEME_KEY = 'htmx-theme';

    (function initTheme() {
      var savedTheme = localStorage.getItem(THEME_KEY) || 'liquid-glass';
      var themeRadio = document.querySelector('input.theme-controller[value="' + savedTheme + '"]');
      if (!themeRadio) {
        savedTheme = 'light';
      }

      document.documentElement.setAttribute('data-theme', savedTheme);

      themeRadio = document.querySelector('input.theme-controller[value="' + savedTheme + '"]');
      if (themeRadio) themeRadio.checked = true;

      document.querySelectorAll('.theme-controller').forEach(function (radio) {
        radio.addEventListener('change', function (e) {
          localStorage.setItem(THEME_KEY, e.target.value);
          document.documentElement.setAttribute('data-theme', e.target.value);
        });
      });
    })();

var DENSITY_KEY = 'htmx-density';

function applyDensity(compact) {
  if (compact) {
    document.documentElement.setAttribute('data-density', 'compact');
  } else {
    document.documentElement.removeAttribute('data-density');
  }
  document.querySelectorAll('.density-toggle-btn').forEach(function (btn) {
    btn.classList.toggle('btn-active', compact);
    btn.setAttribute('aria-pressed', compact ? 'true' : 'false');
  });
}

function toggleCompactDensity() {
  var compact = localStorage.getItem(DENSITY_KEY) !== 'compact';
  localStorage.setItem(DENSITY_KEY, compact ? 'compact' : 'comfortable');
  applyDensity(compact);
}

(function initDensity() {
  applyDensity(localStorage.getItem(DENSITY_KEY) === 'compact');
})();

    function showErrorToast(message) {
      var toast = document.createElement('div');
      toast.className = 'toast-item cursor-pointer transition-opacity duration-500';
      toast.innerHTML = '<div class="alert alert-error shadow-lg mb-2 text-white"><span></span></div>';
      toast.querySelector('span').textContent = message;
      document.getElementById('toast-container').appendChild(toast);
    }

    function dismissToast(toast) {
      if (!toast || toast.dataset.toastDismissing === '1') return;
      toast.dataset.toastDismissing = '1';
      toast.style.opacity = '0';
      setTimeout(function () {
        if (toast && toast.parentNode) toast.remove();
      }, 500);
    }

    function wireToast(toast) {
      if (!toast || toast.dataset.toastWired === '1') return;
      toast.dataset.toastWired = '1';
      toast.classList.add('cursor-pointer');
      toast.addEventListener('click', function () { dismissToast(toast); });
      setTimeout(function () { dismissToast(toast); }, 20000);
    }

    function initToastBehavior() {
      var container = document.getElementById('toast-container');
      if (!container) return;

      container.querySelectorAll(':scope > div').forEach(function (toast) {
        wireToast(toast);
      });

      var observer = new MutationObserver(function (mutations) {
        mutations.forEach(function (mutation) {
          mutation.addedNodes.forEach(function (node) {
            if (!(node instanceof HTMLElement)) return;
            if (node.parentElement === container) {
              wireToast(node);
            }
          });
        });
      });

      observer.observe(container, { childList: true });
    }

    initToastBehavior();

    document.body.addEventListener('htmx:beforeRequest', function (evt) {
      var elt = evt.detail && evt.detail.elt ? evt.detail.elt : null;
      if (elt && elt.hasAttribute('data-disable-on-request')) {
        elt.disabled = true;
        elt.dataset.htmxPendingRestore = '1';
      }
      var form = elt ? elt.closest('form') : null;
      if (form) {
        var buttons = form.querySelectorAll('button[type="submit"]');
        buttons.forEach(function (b) { b.disabled = true; });
      }
    });

    document.body.addEventListener('htmx:afterRequest', function (evt) {
      var elt = evt.detail && evt.detail.elt ? evt.detail.elt : null;
      if (elt && elt.dataset.htmxPendingRestore === '1') {
        elt.disabled = false;
        delete elt.dataset.htmxPendingRestore;
      }
      var form = elt ? elt.closest('form') : null;
      if (form) {
        var buttons = form.querySelectorAll('button[type="submit"]');
        buttons.forEach(function (b) { b.disabled = false; });
      }
    });

    // Ответы с ошибкой htmx не вставляет. Элементы с data-swap-errors (статус ордера в терминале)
    // показывают присланный сервером текст ошибки на своём месте
    document.body.addEventListener('htmx:beforeSwap', function (evt) {
      var detail = evt.detail;
      if (!detail || !detail.target || !detail.target.hasAttribute('data-swap-errors')) return;
      var status = detail.xhr.status;
      if (status >= 400 && status !== 401) {
        detail.shouldSwap = true;
        detail.isError = false;
      }
    });

    document.body.addEventListener('htmx:responseError', function (evt) {
      var xhr = evt.detail && evt.detail.xhr ? evt.detail.xhr : null;
      var status = xhr ? xhr.status : 0;
      var responseText = xhr && typeof xhr.responseText === 'string' ? xhr.responseText : '';
      var backendToastShown = false;

      if (responseText) {
        var wrapper = document.createElement('div');
        wrapper.innerHTML = responseText;

        var oobToasts = wrapper.querySelectorAll('.toast-item');
        if (oobToasts.length > 0) {
          var toastContainer = document.getElementById('toast-container');
          oobToasts.forEach(function (toast) {
            if (!toastContainer) return;
            toastContainer.appendChild(toast);
            wireToast(toast);
            backendToastShown = true;
          });
        }
      }

      if (!backendToastShown) {
        showErrorToast(status === 401 ? 'Session expired. Please login.' : 'Request failed. Please retry.');
      }

      if (status === 401) {
        window.location.href = '/htmx/login';
      }
    });

// TABLE SORTING AND COLUMN TOGGLING
function sortTable(n) {
    const table = document.getElementById('dataTable');
    let switching = true;
    let dir = 'asc';
    let switchcount = 0;
    while (switching) {
        switching = false;
        const rows = table.rows;
        for (let i = 1; i < rows.length - 1; i++) {
            let shouldSwitch = false;
            const x = rows[i].getElementsByTagName('TD')[n];
            const y = rows[i + 1].getElementsByTagName('TD')[n];
            if (!x || !y) continue;

            const xContent = x.innerText || '';
            const yContent = y.innerText || '';
            const xNum = parseFloat(xContent.replace(',', '.'));
            const yNum = parseFloat(yContent.replace(',', '.'));

            if (!isNaN(xNum) && !isNaN(yNum)) {
                if ((dir === 'asc' && xNum > yNum) || (dir === 'desc' && xNum < yNum)) {
                    shouldSwitch = true;
                }
            } else {
                if ((dir === 'asc' && xContent.toLowerCase() > yContent.toLowerCase()) ||
                    (dir === 'desc' && xContent.toLowerCase() < yContent.toLowerCase())) {
                    shouldSwitch = true;
                }
            }

            if (shouldSwitch) {
                rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
                switching = true;
                switchcount++;
                break;
            }
        }

        if (!switching && switchcount === 0 && dir === 'asc') {
            dir = 'desc';
            switching = true;
        }
    }
}

function toggleColumn(colIndex, toggleButton) {
  let table = null;
  if (toggleButton && toggleButton.parentElement) {
    const maybeTable = toggleButton.parentElement.nextElementSibling;
    if (maybeTable && maybeTable.tagName && maybeTable.tagName.toLowerCase() === 'table') {
      table = maybeTable;
    }
  }

  if (!table) {
    const tables = document.querySelectorAll('table#dataTable');
    for (let i = 0; i < tables.length; i++) {
      if (tables[i] && tables[i].rows && tables[i].rows.length > 0) {
        table = tables[i];
        break;
      }
    }
  }

  if (!table) {
    table = document.getElementById('dataTable');
  }

  if (!table || !table.rows || table.rows.length === 0) return;

  const firstCell = table.rows[0].cells[colIndex];
  const willHide = firstCell && firstCell.style.display !== 'none';

    for (let i = 0; i < table.rows.length; i++) {
        const cell = table.rows[i].cells[colIndex];
        if (cell) {
      cell.style.display = willHide ? 'none' : '';
        }
    }

  if (toggleButton) {
    toggleButton.setAttribute('aria-pressed', willHide ? 'true' : 'false');
    if (toggleButton.classList) {
      toggleButton.classList.toggle('btn-active', willHide);
    }
  }
}

// HTMX DASHBOARD VIEW MANAGEMENT
var VIEW_KEY = 'htmx-dashboard-view';
var viewToUrl = {
    accounts: '/htmx/accounts',
    strategies: '/htmx/strategies',
    system: '/htmx/system',
    tester: '/htmx/tester',
    positions: '/htmx/positions',
    orders: '/htmx/orders',
    log: '/htmx/log',
    config: '/htmx/config',
    botstable: '/htmx/botstable',
    terminal: '/htmx/terminal'
};

// Открытый сейчас раздел (localStorage общий для всех вкладок браузера, поэтому храним отдельно)
var currentView = null;

function loadView(view, pushHistory) {
    if (!viewToUrl[view] || !window.htmx) return;
    if (!document.getElementById('htmx-content')) return;
    currentView = view;
    localStorage.setItem(VIEW_KEY, view);

    document.querySelectorAll('.tab').forEach(function (t) { t.classList.remove('tab-active'); });
    var btn = document.querySelector('button.tab[data-view="' + view + '"]');
    if (btn) btn.classList.add('tab-active');

    htmx.ajax('GET', viewToUrl[view], '#htmx-content');
    if (pushHistory) {
        var url = new URL(window.location.href);
        url.searchParams.set('view', view);
        history.pushState({ view: view }, '', url.toString());
    }
}

function currentViewFromUrl() {
    var params = new URLSearchParams(window.location.search);
    var view = params.get('view');
    return viewToUrl[view] ? view : null;
}

function clearModalBody() {
  var modalBody = document.getElementById('htmx-modal-body');
  if (modalBody) {
    modalBody.innerHTML = '';
  }
  // Подсказки редактора настроек добавляются в сам dialog, а не в тело окна
  document.querySelectorAll('#htmx-modal .hb-hint-popover').forEach(function (popup) { popup.remove(); });
}

function resizeModalCharts(expandedHeight) {
  var containers = document.querySelectorAll('#htmx-modal-body [id^="id_chart_"]');
  containers.forEach(function (el) {
    if (!el._lwChart) return;
    var newH = expandedHeight != null ? expandedHeight : el._lwDefaultHeight;
    el._lwCurrentHeight = newH;
    el._lwChart.resize(el.getBoundingClientRect().width, newH);
  });
}

function resizeModalChartsDeferred(expandedHeight) {
  [0, 50, 150].forEach(function (delay) {
    setTimeout(function () { resizeModalCharts(expandedHeight); }, delay);
  });
}

function toggleModalExpand() {
  var box = document.getElementById('htmx-modal-box');
  var btn = document.getElementById('htmx-modal-expand');
  if (!box) return;
  var expanded = box.dataset.expanded === '1';
  if (expanded) {
    box.dataset.expanded = '0';
    box.style.maxWidth = '';
    box.style.width = '';
    box.style.maxHeight = '';
    box.style.height = '';
    box.style.borderRadius = '';
    if (btn) btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75h-4.5m4.5 0v4.5m0-4.5L15 9m5.25 11.25h-4.5m4.5 0v-4.5m0 4.5L15 15"/></svg>';
    if (btn) btn.title = 'Expand';
    resizeModalChartsDeferred(null);
  } else {
    box.dataset.expanded = '1';
    box.style.maxWidth = '100vw';
    box.style.width = '100vw';
    box.style.maxHeight = '100vh';
    box.style.height = '100vh';
    box.style.borderRadius = '0';
    if (btn) btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 9L3.75 3.75M9 9H4.5m4.5 0V4.5M15 9l5.25-5.25M15 9h4.5m-4.5 0V4.5M9 15l-5.25 5.25M9 15H4.5m4.5 0v4.5M15 15l5.25 5.25M15 15h4.5m-4.5 0v4.5"/></svg>';
    if (btn) btn.title = 'Restore';
    var expandedH = Math.max(400, window.innerHeight - 280);
    resizeModalChartsDeferred(expandedH);
  }
  window.dispatchEvent(new Event('resize'));
}

function resetModalExpand() {
  var box = document.getElementById('htmx-modal-box');
  if (box && box.dataset.expanded === '1') {
    box.dataset.expanded = '0';
    box.style.maxWidth = '';
    box.style.width = '';
    box.style.maxHeight = '';
    box.style.height = '';
    box.style.borderRadius = '';
    var btn = document.getElementById('htmx-modal-expand');
    if (btn) {
      btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75h-4.5m4.5 0v4.5m0-4.5L15 9m5.25 11.25h-4.5m4.5 0v-4.5m0 4.5L15 15"/></svg>';
      btn.title = 'Expand';
    }
  }
}

function closeDashboardModal() {
  var modal = document.getElementById('htmx-modal');
  if (!modal) {
    return;
  }

  if (modal.open) {
    modal.close();
  }

  clearModalBody();
  resetModalExpand();
}

document.body.addEventListener('htmx:afterSwap', function (evt) {
    if (evt && evt.detail && evt.detail.target && evt.detail.target.id === 'htmx-modal-body') {
    var modal = document.getElementById('htmx-modal');
    if (!modal) return;

    modal.showModal();

    // Some chart widgets measure width before modal open animation ends.
    // Trigger deferred resize notifications so they can fit full modal width.
    [0, 120, 260].forEach(function (delay) {
      setTimeout(function () {
        window.dispatchEvent(new Event('resize'));
      }, delay);
    });
    }
});

  (function bindModalLifecycle() {
    var modal = document.getElementById('htmx-modal');
    if (!modal) {
      return;
    }

    modal.addEventListener('close', function () {
      cancelModalRequests();
      clearModalBody();
      resetModalExpand();
    });
  })();

// Индикатор загрузки окна: если ответ для окна задерживается, оно открывается (или остаётся открытым)
// со спиннером. Быстрые ответы спиннер не показывают
var MODAL_LOADING_DELAY_MS = 250;
var modalRequests = new Map(); // XMLHttpRequest -> { timer, openedModal }

function setModalLoading(visible) {
  var indicator = document.getElementById('htmx-modal-loading');
  if (indicator) indicator.classList.toggle('hidden', !visible);
}

// Забывает запрос; возвращает его описание или undefined, если запрос не для окна или уже учтён
function finishModalRequest(xhr) {
  var request = modalRequests.get(xhr);
  if (!request) return undefined;
  clearTimeout(request.timer);
  modalRequests.delete(xhr);
  if (!modalRequests.size) setModalLoading(false);
  return request;
}

// Окно закрыли, не дождавшись ответа: отменяем запрос, чтобы окно не открылось снова
function cancelModalRequests() {
  Array.from(modalRequests.keys()).forEach(function (xhr) {
    finishModalRequest(xhr);
    // у завершённого запроса abort() стёр бы ещё не обработанный ответ
    if (xhr.readyState !== XMLHttpRequest.DONE) xhr.abort();
  });
}

document.body.addEventListener('htmx:beforeSend', function (evt) {
  var target = evt.detail.target;
  var modal = document.getElementById('htmx-modal');
  if (!modal || !target || target.id !== 'htmx-modal-body') return;

  var request = { openedModal: false };
  request.timer = setTimeout(function () {
    setModalLoading(true);
    if (!modal.open) {
      request.openedModal = true;
      modal.showModal();
    }
  }, MODAL_LOADING_DELAY_MS);
  modalRequests.set(evt.detail.xhr, request);
});

// Ответ получен (с содержимым или с ошибкой)
document.body.addEventListener('htmx:afterRequest', function (evt) {
  var request = finishModalRequest(evt.detail.xhr);
  // Ошибка: окно, открытое только ради спиннера, закрываем — сообщение уже показано тостом
  if (request && request.openedModal && !evt.detail.successful) closeDashboardModal();
});

// Нет связи с сервером: htmx не сообщает об этом пользователю сам
document.body.addEventListener('htmx:sendError', function (evt) {
  var target = evt.detail.target;
  if (target && target.id === 'htmx-modal-body') showErrorToast('Request failed. Please retry.');
});

document.body.addEventListener('click', function (evt) {
    var button = evt.target.closest('button[data-view]');
    if (!button) return;

    var view = button.getAttribute('data-view');
    if (viewToUrl[view]) {
        currentView = view;
        localStorage.setItem(VIEW_KEY, view);
        document.querySelectorAll('.tab').forEach(function (t) { t.classList.remove('tab-active'); });
        button.classList.add('tab-active');

        var url = new URL(window.location.href);
        url.searchParams.set('view', view);
        history.replaceState({ view: view }, '', url.toString());
    }
});

document.body.addEventListener('closeModal', function () {
  closeDashboardModal();
});

// Публикация отчёта тестера: окно закрывается сразу, отправка идёт в фоне, результат приходит тостом
function submitTesterPublish(form) {
  var container = document.getElementById('toast-container');
  function appendToasts(html) {
    if (!container || !html) return false;
    var wrapper = document.createElement('div');
    wrapper.innerHTML = html;
    var toasts = wrapper.querySelectorAll('.toast-item');
    toasts.forEach(function (t) { container.appendChild(t); });
    return toasts.length > 0;
  }

  var data = new URLSearchParams(new FormData(form));
  var started = form.querySelector('template.publish-started-toast');
  if (started) appendToasts(started.innerHTML);
  closeDashboardModal();

  fetch(form.getAttribute('action'), { method: 'POST', body: data, credentials: 'same-origin' })
    .then(function (resp) {
      if (resp.status === 401) window.location.href = '/htmx/login';
      return resp.text();
    })
    .then(function (html) {
      if (!appendToasts(html)) showErrorToast('Request failed. Please retry.');
    })
    .catch(function () { showErrorToast('Request failed. Please retry.'); });
  return false;
}

// Перезагрузка открытого раздела с сохранением введённых чисел (лот в терминале, процент закрытия)
// и статусов отправленных ордеров
function reloadCurrentView() {
  var content = document.getElementById('htmx-content');
  if (!content || !viewToUrl[currentView]) return;
  // Раздел с автообновлением: точечное обновление (live-refresh.js) сохраняет всё введённое и раскрытое само
  if (window.hbLive && window.hbLive.handles(currentView)) {
    window.hbLive.refreshNow();
    return;
  }

  var saved = Array.from(content.querySelectorAll('input[type="number"][id], [data-swap-errors][id]'))
    .map(function (el) {
      return { id: el.id, value: el.tagName === 'INPUT' ? el.value : el.innerHTML };
    });
  var view = currentView;

  htmx.ajax('GET', viewToUrl[view], '#htmx-content').then(function () {
    if (view !== currentView) return;
    saved.forEach(function (item) {
      var el = document.getElementById(item.id);
      if (!el) return;
      if (el.tagName === 'INPUT') el.value = item.value;
      else el.innerHTML = item.value;
    });
  });
}

// Обновляем только открытый раздел: изменение могло прийти из окна поверх другой вкладки.
// Окно закрывается отдельным событием closeModal из того же заголовка HX-Trigger.
var viewRefreshTimer = null;
function refreshIfShown(views, delayMs) {
  if (views.indexOf(currentView) === -1) return;
  clearTimeout(viewRefreshTimer);
  viewRefreshTimer = setTimeout(function () {
    if (views.indexOf(currentView) !== -1) reloadCurrentView();
  }, delayMs || 0);
}

document.body.addEventListener('accountsChanged', function () {
  refreshIfShown(['accounts', 'botstable']);
});

document.body.addEventListener('strategiesChanged', function () {
  refreshIfShown(['strategies', 'botstable']);
});

document.body.addEventListener('botsChanged', function () {
  refreshIfShown(['botstable', 'strategies']);
});

// Закрытие позиций и отмена ордеров только отправлены на биржу — даём боту получить новое состояние
var EXCHANGE_REFRESH_DELAY_MS = 2000;

document.body.addEventListener('positionsChanged', function () {
  refreshIfShown(['positions', 'terminal', 'botstable'], EXCHANGE_REFRESH_DELAY_MS);
});

document.body.addEventListener('ordersChanged', function () {
  refreshIfShown(['orders'], EXCHANGE_REFRESH_DELAY_MS);
});

// Статус и таблица тестера слушают testerChanged сами; здесь только список файлов (появляются новые отчёты)
document.body.addEventListener('testerChanged', function () {
  document.body.dispatchEvent(new CustomEvent('testerFilesChanged'));
});

window.addEventListener('popstate', function (evt) {
    var view = (evt.state && evt.state.view) || currentViewFromUrl() || localStorage.getItem(VIEW_KEY) || 'accounts';
    loadView(view, false);
});

// ── Переключение разделов клавиатурой ─────────────────────────────────────────
// ← → — соседний раздел (по кругу) с любого места страницы, кроме случаев, когда стрелки нужны
// самой странице: фокус в поле ввода или списке, открыто окно, прокручивается широкая таблица.
// На строке вкладок ещё Home / End, а разметка — как у вкладок (role="tab", aria-selected),
// фокус Tab попадает только на активную вкладку.
(function initTabKeys() {
  var bar = document.querySelector('.tabs[role="tablist"]');
  if (!bar) return;
  // Зажатая стрелка быстро пробегает вкладки, а загружается только та, на которой остановились
  var LOAD_DELAY_MS = 200;
  var loadTimer = null;
  var lastPointerTarget = null;

  function tabs() { return Array.prototype.slice.call(bar.querySelectorAll('.tab[data-view]')); }

  function syncAria() {
    tabs().forEach(function (t) {
      var active = t.classList.contains('tab-active');
      t.setAttribute('role', 'tab');
      t.setAttribute('aria-selected', active ? 'true' : 'false');
      t.tabIndex = active ? 0 : -1;
    });
  }
  syncAria();
  // Активную вкладку меняют loadView, щелчок и эта клавиатура — следим за классом
  new MutationObserver(syncAria).observe(bar, { subtree: true, attributes: true, attributeFilter: ['class'] });

  document.addEventListener('pointerdown', function (e) { lastPointerTarget = e.target; }, true);

  // Элемент сам прокручивается по горизонтали: стрелки нужны ему
  function inHorizontalScroller(el) {
    for (; el && el !== document.body && el.nodeType === 1; el = el.parentElement) {
      var ox = getComputedStyle(el).overflowX;
      if ((ox === 'auto' || ox === 'scroll') && el.scrollWidth > el.clientWidth + 1) return true;
    }
    return false;
  }

  function arrowsBelongToPage(target) {
    var modal = document.getElementById('htmx-modal');
    if (modal && modal.open) return true;
    if (!(target instanceof Element)) return false;
    if (target.isContentEditable) return true;
    if (target.closest('input, textarea, select, [role="slider"], [role="listbox"], [role="menu"], [role="tablist"], .dropdown')) return true;
    if (lastPointerTarget && document.contains(lastPointerTarget) && inHorizontalScroller(lastPointerTarget)) return true;
    return false;
  }

  function select(tab, focusTab) {
    tabs().forEach(function (t) { t.classList.toggle('tab-active', t === tab); });
    if (focusTab) tab.focus();
    if (window.hbSound) window.hbSound.play('tab');
    clearTimeout(loadTimer);
    loadTimer = setTimeout(function () { tab.click(); }, LOAD_DELAY_MS);
  }

  document.addEventListener('keydown', function (e) {
    if (e.defaultPrevented || e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
    var inBar = bar.contains(document.activeElement);
    var key = e.key;
    var isArrow = key === 'ArrowLeft' || key === 'ArrowRight';
    if (!isArrow && !(inBar && (key === 'Home' || key === 'End'))) return;
    if (!inBar && arrowsBelongToPage(e.target)) return;

    var list = tabs();
    if (!list.length) return;
    var i = list.findIndex(function (t) { return t.classList.contains('tab-active'); });
    if (i < 0) i = 0;
    var n = list.length;
    var next = key === 'ArrowRight' ? (i + 1) % n
      : key === 'ArrowLeft' ? (i - 1 + n) % n
      : key === 'Home' ? 0 : n - 1;
    e.preventDefault();
    select(list[next], inBar);
  });
})();

(function initDashboard() {
    if (!document.getElementById('htmx-content')) return;
    var initialView = currentViewFromUrl() || localStorage.getItem(VIEW_KEY) || 'botstable';
    loadView(initialView, false);
})();

/* ===== Промо онлайн-версии (#hb-promo, разметка в page_shell.html) =====
   Красная точка горит, пока предложение ни разу не открывали.
   «Не сейчас» сворачивает ярлык до значка на QUIET_DAYS дней.
   Закрытие: крестик, Esc или щелчок мимо карточки. */
(function initPromo() {
  var root = document.getElementById('hb-promo');
  if (!root) return;
  var launcher = document.getElementById('hb-promo-launcher');
  var panel = document.getElementById('hb-promo-panel');
  if (!launcher || !panel) return;

  var SEEN_KEY = 'hbPromoSeen';
  var QUIET_KEY = 'hbPromoQuietUntil';
  var QUIET_DAYS = 7;

  function read(key) { try { return localStorage.getItem(key); } catch (e) { return null; } }
  function write(key, value) { try { localStorage.setItem(key, value); } catch (e) { } }

  // Кто уже закрывал старый Y2K-виджет — тот предложение видел
  if (read('y2kAdDismissedAt')) {
    write(SEEN_KEY, '1');
    try { localStorage.removeItem('y2kAdDismissedAt'); } catch (e) { }
  }

  function isQuiet() {
    var until = parseInt(read(QUIET_KEY) || '0', 10);
    return until > Date.now();
  }

  root.classList.toggle('has-news', !read(SEEN_KEY));
  root.classList.toggle('is-quiet', isQuiet());
  panel.setAttribute('tabindex', '-1');

  function isOpen() { return root.classList.contains('is-open'); }

  function open() {
    root.classList.add('is-open');
    root.classList.remove('has-news');
    launcher.setAttribute('aria-expanded', 'true');
    write(SEEN_KEY, '1');
    panel.focus({ preventScroll: true });
  }

  function close(returnFocus) {
    if (!isOpen()) return;
    var focusWasInside = panel.contains(document.activeElement);
    root.classList.remove('is-open');
    launcher.setAttribute('aria-expanded', 'false');
    if (returnFocus || focusWasInside) launcher.focus({ preventScroll: true });
  }

  launcher.addEventListener('click', function () {
    if (isOpen()) close(true); else open();
  });

  panel.addEventListener('click', function (e) {
    var t = e.target;
    if (!(t instanceof Element)) return;
    if (t.closest('[data-promo-close]')) {
      close(true);
    } else if (t.closest('[data-promo-later]')) {
      write(QUIET_KEY, String(Date.now() + QUIET_DAYS * 24 * 3600 * 1000));
      root.classList.add('is-quiet');
      close(true);
    } else if (t.closest('.hb-promo-cta')) {
      // Ссылка открывается в новой вкладке; карточку здесь можно убрать
      setTimeout(function () { close(false); }, 0);
    }
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && isOpen()) close(true);
  });

  document.addEventListener('pointerdown', function (e) {
    if (isOpen() && !root.contains(e.target)) close(false);
  });
})();
/* ===== End промо онлайн-версии ===== */

// END OF FILE
