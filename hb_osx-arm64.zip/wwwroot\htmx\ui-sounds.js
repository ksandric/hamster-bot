// Звуки интерфейса: короткие 8-битные эффекты, синтезированные Web Audio (без звуковых файлов).
// Работают в любой теме; по умолчанию выключены. Включает их кнопка .sound-toggle-btn
// в шапке (dashboard.html), выбор хранится в localStorage.
// Другие скрипты могут проиграть звук сами: window.hbSound.play('boot').
(function () {
  'use strict';

  var KEY = 'hbUiSound';
  var audio = null, master = null;

  function read() { try { return localStorage.getItem(KEY); } catch (e) { return null; } }
  function write(v) { try { localStorage.setItem(KEY, v); } catch (e) { } }

  var on = read() === 'on';
  // Ключ прежней версии темы Neon Arcade (там звук был включён по умолчанию) больше не нужен
  try { localStorage.removeItem('hbArcadeSfx'); } catch (e) { }

  // AudioContext создаётся только по действию пользователя — так требуют браузеры
  function ctx() {
    if (!audio) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      audio = new AC();
      master = audio.createGain();
      master.gain.value = 0.16;
      master.connect(audio.destination);
    }
    if (audio.state === 'suspended') audio.resume();
    return audio;
  }

  // Один тон: частота (с возможным глиссандо), длительность, форма волны
  function tone(freq, dur, opt) {
    opt = opt || {};
    var a = ctx(); if (!a) return;
    var t0 = a.currentTime + (opt.at || 0);
    var osc = a.createOscillator();
    var g = a.createGain();
    osc.type = opt.type || 'square';
    osc.frequency.setValueAtTime(freq, t0);
    if (opt.to) osc.frequency.exponentialRampToValueAtTime(opt.to, t0 + dur);
    var vol = opt.vol == null ? 0.5 : opt.vol;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol, t0 + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g); g.connect(master);
    osc.start(t0); osc.stop(t0 + dur + 0.02);
  }

  // Шумовой удар
  function noise(dur, opt) {
    opt = opt || {};
    var a = ctx(); if (!a) return;
    var t0 = a.currentTime + (opt.at || 0);
    var len = Math.floor(a.sampleRate * dur);
    var buf = a.createBuffer(1, len, a.sampleRate);
    var data = buf.getChannelData(0);
    for (var i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len);
    var src = a.createBufferSource();
    src.buffer = buf;
    var f = a.createBiquadFilter();
    f.type = 'lowpass';
    f.frequency.value = opt.cutoff || 900;
    var g = a.createGain();
    g.gain.value = opt.vol == null ? 0.6 : opt.vol;
    src.connect(f); f.connect(g); g.connect(master);
    src.start(t0);
  }

  var SFX = {
    blip:    function () { tone(660, 0.05, { to: 990, vol: 0.35 }); },
    tick:    function () { tone(1800, 0.025, { type: 'triangle', vol: 0.25 }); },
    tab:     function () { tone(784, 0.06, { type: 'triangle', vol: 0.45 }); tone(1175, 0.09, { type: 'triangle', vol: 0.45, at: 0.06 }); },
    coin:    function () { tone(1046, 0.07, { vol: 0.35 }); tone(1568, 0.32, { vol: 0.35, at: 0.07 }); },
    powerup: function () { [523, 659, 784, 1046, 1318].forEach(function (f, i) { tone(f, 0.09, { vol: 0.32, at: i * 0.055 }); }); },
    pause:   function () { tone(880, 0.08, { vol: 0.35 }); tone(587, 0.14, { vol: 0.35, at: 0.08 }); },
    thud:    function () { noise(0.22, { cutoff: 700, vol: 0.7 }); tone(140, 0.2, { to: 50, type: 'sine', vol: 0.6 }); },
    open:    function () { tone(220, 0.16, { to: 880, type: 'sawtooth', vol: 0.18 }); tone(1760, 0.08, { type: 'triangle', vol: 0.25, at: 0.15 }); },
    close:   function () { tone(880, 0.14, { to: 220, type: 'sawtooth', vol: 0.16 }); },
    success: function () { tone(1318, 0.07, { type: 'triangle', vol: 0.3 }); tone(1760, 0.16, { type: 'triangle', vol: 0.3, at: 0.07 }); },
    warning: function () { tone(660, 0.09, { type: 'triangle', vol: 0.35 }); tone(660, 0.09, { type: 'triangle', vol: 0.35, at: 0.13 }); },
    error:   function () { tone(110, 0.14, { vol: 0.45 }); tone(104, 0.22, { vol: 0.45, at: 0.17 }); },
    boot:    function () {
      tone(55, 0.6, { to: 880, type: 'sawtooth', vol: 0.12 });
      [392, 523, 659, 784, 1046].forEach(function (f, i) { tone(f, 0.12, { type: 'square', vol: 0.28, at: 0.45 + i * 0.07 }); });
      tone(1568, 0.5, { type: 'triangle', vol: 0.3, at: 0.82 });
    }
  };

  function play(name) {
    if (!on || !SFX[name]) return;
    try { SFX[name](); } catch (e) { }
  }

  // ── Кнопка в шапке ─────────────────────────────────────────────────
  function syncButtons() {
    document.querySelectorAll('.sound-toggle-btn').forEach(function (btn) {
      btn.classList.toggle('btn-active', on);
      btn.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
  }

  function setOn(value) {
    on = !!value;
    write(on ? 'on' : 'off');
    syncButtons();
    if (on) SFX.coin(); // сразу слышно, что звук включился
  }

  // ── Какие действия звучат ──────────────────────────────────────────
  // Только настоящие нажатия пользователя: автообновления страниц htmx молчат.
  document.addEventListener('click', function (e) {
    var t = e.target instanceof Element ? e.target : null;
    if (!t || !e.isTrusted) return;
    if (t.closest('.sound-toggle-btn')) { setOn(!on); return; }
    if (!on) return;
    var themeRadio = t.closest('.theme-controller');
    if (themeRadio) {
      // У Neon Arcade свой звук включения (theme-neon-arcade.js)
      if (themeRadio.value !== 'neon-arcade') play('tick');
      return;
    }
    var b = t.closest('.btn, .tab, .bt-pause-btn, .bt-icon-btn, .bt-symbol-btn, summary, input[type="checkbox"], input[type="radio"], #hb-promo-launcher');
    if (!b || b.disabled) return;
    var c = b.classList;
    if (c.contains('tab')) play('tab');
    else if (c.contains('btn-primary')) play('coin');
    else if (c.contains('btn-success')) play('powerup');
    else if (c.contains('btn-warning')) play('pause');
    else if (c.contains('btn-error')) play('thud');
    else if (b.tagName === 'SUMMARY' || b.tagName === 'INPUT') play('tick');
    else play('blip');
  }, true);

  // Всплывающие уведомления: ошибка, предупреждение, успех
  function watchToasts() {
    var box = document.getElementById('toast-container');
    if (!box || !window.MutationObserver) return;
    new MutationObserver(function (list) {
      for (var i = 0; i < list.length; i++) {
        for (var j = 0; j < list[i].addedNodes.length; j++) {
          var n = list[i].addedNodes[j];
          if (n.nodeType !== 1 || !n.querySelector) continue;
          if (n.querySelector('.alert-error')) { play('error'); return; }
          if (n.querySelector('.alert-warning')) { play('warning'); return; }
          if (n.querySelector('.alert-success')) { play('success'); return; }
        }
      }
    }).observe(box, { childList: true });
  }

  // Модальное окно: звук открытия и закрытия
  function watchModal() {
    var dlg = document.getElementById('htmx-modal');
    if (!dlg || !window.MutationObserver) return;
    var wasOpen = dlg.hasAttribute('open');
    new MutationObserver(function () {
      var isOpen = dlg.hasAttribute('open');
      if (isOpen !== wasOpen) play(isOpen ? 'open' : 'close');
      wasOpen = isOpen;
    }).observe(dlg, { attributes: true, attributeFilter: ['open'] });
  }

  window.hbSound = {
    play: play,
    isOn: function () { return on; },
    setOn: setOn
  };

  function start() {
    syncButtons();
    watchToasts();
    watchModal();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
  // Шапку могут перерисовать запросом htmx — состояние кнопки восстанавливаем
  document.addEventListener('htmx:afterSwap', syncButtons);
})();
