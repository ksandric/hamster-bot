// Автообновление открытого раздела панели: «Боты», «Терминал», «Позиции», «Ордера», «API», «Стратегии».
//
// Как экономится работа:
//  • Опрашивается только открытый раздел и только пока вкладка браузера видна и не открыто окно.
//  • Сервер отдаёт ETag (хеш HTML); если ничего не изменилось — 304 без тела, страница не трогается.
//    Подряд идущие «без изменений» постепенно замедляют опрос (до ×4), любое изменение — сразу к обычному темпу.
//  • Изменившийся HTML не заменяет раздел целиком, а «досматривается» в существующий DOM: меняются только
//    отличающиеся тексты и атрибуты, строки таблиц сопоставляются по своим ссылкам (hx-get/hx-post).
//    Поэтому сохраняются прокрутка, фокус, введённые числа, раскрытые аккаунты, сортировка, объединённая
//    таблица ботов, скрытые колонки, открытые плашки PnL и обработчики событий.
//  • Если изменилась сама структура раздела (добавлен аккаунт, бот, таблица) — раздел перезагружается
//    обычным образом, а сортировка и раскрытые блоки восстанавливаются.
//  • Пока пользователь выделяет текст, держит нажатой кнопку мыши или открыл выпадающий список
//    внутри раздела — обновление откладывается.
//
// Индикатор состояния — #hb-live в строке вкладок (dashboard.html).
// Элементы с data-live-keep (и data-swap-errors — статусы отправленных ордеров) не обновляются.
(function () {
  'use strict';

  var content = document.getElementById('htmx-content');
  if (!content || !window.htmx || !window.fetch) return;

  // Период опроса по разделам, мс. Лог, «Система» и тестер опрашивают себя сами
  var INTERVALS = { botstable: 2000, terminal: 2000, positions: 2000, orders: 3000, accounts: 10000, strategies: 10000 };
  var MAX_SLOWDOWN = 4;
  var RETRY_MAX_MS = 30000;
  var BUSY_RETRY_MS = 700;

  var etags = {};              // раздел -> ETag показанной версии
  var timer = null;
  var inflight = null;         // AbortController текущего запроса
  var failures = 0;            // подряд неудачных запросов (для паузы между повторами)
  var unchanged = 0;           // подряд ответов «без изменений» (для замедления)
  var contentLoading = false;  // htmx грузит что-то в #htmx-content
  var showingView = false;     // в #htmx-content именно раздел, а не открытая из него подстраница
  var pointerDown = false;
  var indicator = null;

  function view() { return window.currentView; }
  function urlOf(v) { return window.viewToUrl && window.viewToUrl[v]; }
  function isLive(v) { return !!INTERVALS[v] && !!urlOf(v); }

  // ── Индикатор ──────────────────────────────────────────────────────
  function setStatus(state) {
    indicator = indicator || document.getElementById('hb-live');
    if (!indicator) return;
    if (indicator.dataset.state !== state) {
      indicator.dataset.state = state;
      var title = indicator.getAttribute('data-title-' + state);
      if (title) indicator.title = title;
    }
  }

  function pulse() {
    if (!indicator) return;
    indicator.classList.remove('hb-live-pulse');
    requestAnimationFrame(function () { if (indicator) indicator.classList.add('hb-live-pulse'); });
  }

  // ── Планирование ───────────────────────────────────────────────────
  function stop() {
    clearTimeout(timer);
    timer = null;
    if (inflight) { inflight.abort(); inflight = null; }
  }

  function schedule(delay) {
    clearTimeout(timer);
    var v = view();
    if (!isLive(v) || !showingView) { setStatus('off'); return; }
    if (!failures) setStatus('live');
    if (delay == null) {
      var base = INTERVALS[v];
      delay = failures
        ? Math.min(RETRY_MAX_MS, base * Math.pow(2, failures))
        : base * Math.min(MAX_SLOWDOWN, 1 + Math.floor(unchanged / 3));
    }
    timer = setTimeout(tick, delay);
  }

  function modalOpen() {
    var modal = document.getElementById('htmx-modal');
    return !!(modal && modal.open);
  }

  // Пользователь что-то делает в разделе — обновление подождёт
  function userBusy() {
    if (pointerDown || contentLoading) return true;
    var sel = window.getSelection && window.getSelection();
    if (sel && !sel.isCollapsed && sel.anchorNode && content.contains(sel.anchorNode)) return true;
    var active = document.activeElement;
    if (active && content.contains(active) && active.closest('.dropdown')) return true;
    return false;
  }

  function tick() {
    var v = view();
    if (!isLive(v) || !showingView) { setStatus('off'); return; }
    // Скрытая вкладка и открытое окно: ждём событий visibilitychange / close
    if (document.hidden || modalOpen()) { setStatus('paused'); return; }
    if (userBusy()) { schedule(BUSY_RETRY_MS); return; }
    request(v);
  }

  function request(v) {
    if (inflight) inflight.abort();
    var ctrl = new AbortController();
    inflight = ctrl;
    var headers = { 'HX-Request': 'true', 'X-HB-Live': '1' };
    if (etags[v]) headers['If-None-Match'] = etags[v];

    fetch(urlOf(v), { headers: headers, credentials: 'same-origin', cache: 'no-store', signal: ctrl.signal })
      .then(function (resp) {
        if (resp.status === 401) { window.location.href = '/htmx/login'; return 'stop'; }
        if (resp.status === 304) return null;
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        var etag = resp.headers.get('ETag');
        return resp.text().then(function (html) { return { html: html, etag: etag }; });
      })
      .then(function (res) {
        if (inflight !== ctrl) return; // запрос заменён более новым
        inflight = null;
        if (res === 'stop') return;
        failures = 0;
        setStatus('live');
        if (view() !== v || !showingView) { schedule(); return; }
        if (res === null) { unchanged++; schedule(); return; }
        // Ответ пришёл, пока пользователь начал выделять текст или нажал кнопку — применим в следующий раз
        if (userBusy() || modalOpen()) { schedule(BUSY_RETRY_MS); return; }
        unchanged = 0;
        etags[v] = res.etag;
        apply(v, res.html);
        schedule();
      })
      .catch(function (err) {
        if (inflight === ctrl) inflight = null;
        if (err && err.name === 'AbortError') return;
        failures++;
        setStatus('offline');
        schedule();
      });
  }

  // ── Состояние раздела, которое создаёт сам браузер ────────────────
  function tablesOf(root) { return Array.prototype.slice.call(root.querySelectorAll('table')); }

  function captureState() {
    var state = { combined: !!content.querySelector('#bt-combined-wrap'), sorts: [], details: [], hiddenCols: [] };
    tablesOf(content).forEach(function (table, i) {
      // Скрытые пользователем колонки (positions.html, orders.html): у новых строк их тоже надо скрыть
      table.querySelectorAll('thead [data-col]').forEach(function (th) {
        if (th.style.display === 'none') state.hiddenCols.push({ key: table.id || i, col: th.getAttribute('data-col') });
      });
      var th = table.querySelector('thead th[data-sort-dir="asc"], thead th[data-sort-dir="desc"]');
      if (th) {
        state.sorts.push({
          key: table.id || i,
          col: Array.prototype.indexOf.call(th.parentNode.children, th),
          asc: th.dataset.sortDir === 'asc',
          type: th.dataset.sortType
        });
      }
    });
    content.querySelectorAll('details').forEach(function (d) { state.details.push(d.open); });
    return state;
  }

  // Та же сортировка, что в шаблонах разделов (botstable.html, positions.html, …)
  function sortRows(table, col, asc, type) {
    var ths = table.querySelectorAll('thead th[data-sort-type]');
    ths.forEach(function (h) { delete h.dataset.sortAsc; h.dataset.sortDir = ''; });
    var th = table.querySelector('thead tr') && table.querySelector('thead tr').children[col];
    if (th) { th.dataset.sortAsc = asc ? 'true' : 'false'; th.dataset.sortDir = asc ? 'asc' : 'desc'; }
    var tbody = table.querySelector('tbody');
    if (!tbody) return;
    var rows = Array.prototype.slice.call(tbody.querySelectorAll('tr.bt-row'));
    function value(row) {
      var cell = row.cells[col];
      return (cell && cell.dataset.sortVal != null) ? cell.dataset.sortVal : (cell ? cell.textContent.trim() : '');
    }
    rows.sort(function (a, b) {
      var va = value(a), vb = value(b);
      if (type === 'num') {
        va = parseFloat(va.replace(/[^0-9.+\-]/g, '')) || 0;
        vb = parseFloat(vb.replace(/[^0-9.+\-]/g, '')) || 0;
        return asc ? va - vb : vb - va;
      }
      return asc ? va.localeCompare(vb) : vb.localeCompare(va);
    });
    var current = Array.prototype.slice.call(tbody.querySelectorAll('tr.bt-row'));
    if (rows.every(function (r, i) { return r === current[i]; })) return;
    rows.forEach(function (r) { tbody.appendChild(r); });
  }

  function applyState(root, state) {
    if (state.combined && typeof window.hbCombineBotTables === 'function') window.hbCombineBotTables(root);
    var tables = tablesOf(root);
    function find(key) { return typeof key === 'string' ? root.querySelector('#' + CSS.escape(key)) : tables[key]; }
    state.sorts.forEach(function (s) {
      var table = find(s.key);
      if (table) sortRows(table, s.col, s.asc, s.type);
    });
    state.hiddenCols.forEach(function (h) {
      var table = find(h.key);
      if (table) table.querySelectorAll('[data-col="' + CSS.escape(h.col) + '"]').forEach(function (el) { el.style.display = 'none'; });
    });
    root.querySelectorAll('details').forEach(function (d, i) {
      if (i < state.details.length) d.open = state.details[i];
    });
  }

  // «Скелет» раздела: всё, кроме содержимого таблиц. Если он поменялся — нужна полная перезагрузка
  function skeleton(root) {
    var out = [];
    (function walk(node) {
      for (var el = node.firstElementChild; el; el = el.nextElementSibling) {
        out.push(el.tagName + (el.id ? '#' + el.id : ''));
        if (el.tagName !== 'TBODY' && el.tagName !== 'SCRIPT' && !isKept(el)) { out.push('('); walk(el); out.push(')'); }
      }
    })(root);
    return out.join('');
  }

  // ── Применение нового HTML ─────────────────────────────────────────
  function apply(v, html) {
    var tpl = document.createElement('template');
    tpl.innerHTML = html;
    var next = tpl.content;
    var state = captureState();
    applyState(next, state);

    if (skeleton(content) !== skeleton(next)) {
      fullReload(v, state);
      return;
    }
    touched = [];
    if (morphChildren(content, next)) {
      touched.forEach(function (el) { if (el.isConnected) htmx.process(el); });
      pulse();
    }
    touched = [];
  }

  // Структура изменилась: обычная загрузка раздела (скрипты шаблона выполнятся заново),
  // затем возвращаем сортировку, раскрытые блоки и введённые числа
  function fullReload(v, state) {
    var saved = Array.prototype.slice.call(content.querySelectorAll('input[type="number"][id], [data-swap-errors][id]'))
      .map(function (el) { return { id: el.id, value: el.tagName === 'INPUT' ? el.value : el.innerHTML }; });
    content.classList.add('hb-live'); // без затухания при замене
    htmx.ajax('GET', urlOf(v), { target: '#htmx-content', headers: { 'X-HB-Live': '1' } }).then(function () {
      content.classList.remove('hb-live');
      if (view() !== v) return;
      state.combined = false; // объединённый вид шаблон botstable восстанавливает сам
      applyState(content, state);
      saved.forEach(function (item) {
        var el = document.getElementById(item.id);
        if (!el) return;
        if (el.tagName === 'INPUT') el.value = item.value; else el.innerHTML = item.value;
      });
      pulse();
    }, function () { content.classList.remove('hb-live'); });
  }

  // ── Морфинг DOM ────────────────────────────────────────────────────
  // Классы, которые ставит браузер: их не снимаем
  var CLIENT_CLASS = /^(htmx-|hb-tick-|bt-stat-open$|pc-hidden$|oc-hidden$)/;

  // Новые узлы и элементы с изменёнными hx-атрибутами: только их потом обрабатывает htmx
  var touched = [];
  function adopt(node) { if (node.nodeType === 1) touched.push(node); return node; }

  function isKept(el) {
    return el.hasAttribute('data-live-keep') || el.hasAttribute('data-swap-errors');
  }

  function sameKind(a, b) {
    if (a.nodeType !== b.nodeType) return false;
    if (a.nodeType !== 1) return true;
    return a.tagName === b.tagName && (a.id || '') === (b.id || '');
  }

  function morphClass(live, next) {
    var keep = Array.prototype.filter.call(live.classList, function (c) { return CLIENT_CLASS.test(c); });
    var wanted = (next.getAttribute('class') || '').split(/\s+/).filter(Boolean);
    keep.forEach(function (c) { if (wanted.indexOf(c) === -1) wanted.push(c); });
    var value = wanted.join(' ');
    if ((live.getAttribute('class') || '') === value) return false;
    if (value) live.setAttribute('class', value); else live.removeAttribute('class');
    return true;
  }

  function morphAttrs(live, next) {
    var changed = false;
    var isDetails = live.tagName === 'DETAILS';
    for (var i = 0; i < next.attributes.length; i++) {
      var a = next.attributes[i];
      if (a.name === 'class' || (isDetails && a.name === 'open')) continue;
      if (live.getAttribute(a.name) !== a.value) {
        live.setAttribute(a.name, a.value);
        changed = true;
        if (a.name.indexOf('hx-') === 0) touched.push(live);
      }
    }
    for (var j = live.attributes.length - 1; j >= 0; j--) {
      var name = live.attributes[j].name;
      if (next.hasAttribute(name) || name === 'class') continue;
      // Состояние, которое держит браузер: раскрытие, скрытые колонки (style), блокировка на время запроса, data-*
      if (name === 'open' || name === 'style' || name === 'disabled' || name.indexOf('data-') === 0) continue;
      live.removeAttribute(name);
      changed = true;
    }
    if (morphClass(live, next)) changed = true;
    return changed;
  }

  function morphNode(live, next) {
    if (live.nodeType === 3 || live.nodeType === 8) {
      if (live.nodeValue === next.nodeValue) return false;
      var old = live.nodeValue;
      live.nodeValue = next.nodeValue;
      if (live.nodeType === 3) tickFlash(live, old, next.nodeValue);
      return true;
    }
    if (live.nodeType !== 1) return false;
    if (live.tagName === 'SCRIPT' || isKept(live)) return false;
    var changed = morphAttrs(live, next);
    // Открытый пользователем список не перестраиваем
    if (live.tagName === 'SELECT' && live === document.activeElement) return changed;
    if (morphChildren(live, next)) changed = true;
    return changed;
  }

  function morphChildren(live, next) {
    if (live.tagName === 'TBODY') return morphRows(live, next);
    var changed = false;
    var nextNodes = Array.prototype.slice.call(next.childNodes);
    for (var i = 0; i < nextNodes.length; i++) {
      var n = nextNodes[i];
      var l = live.childNodes[i];
      if (!l) { live.appendChild(adopt(n)); changed = true; continue; }
      if (!sameKind(l, n)) { live.replaceChild(adopt(n), l); changed = true; continue; }
      if (morphNode(l, n)) changed = true;
    }
    while (live.childNodes.length > nextNodes.length) { live.removeChild(live.lastChild); changed = true; }
    return changed;
  }

  // Строку таблицы узнаём по её действиям: ссылки hx-get/hx-post/hx-vals уникальны для бота, позиции, ордера
  function rowKey(tr) {
    if (tr.dataset && tr.dataset.key) return tr.dataset.key;
    var parts = [];
    tr.querySelectorAll('[hx-get], [hx-post], [hx-vals], a[href], input[type="hidden"]').forEach(function (el) {
      parts.push(el.getAttribute('hx-get') || el.getAttribute('hx-post') || el.getAttribute('hx-vals') || el.getAttribute('href') ||
        (el.name + '=' + el.value));
    });
    return parts.join('|');
  }

  function keyMap(rows) {
    var map = new Map();
    for (var i = 0; i < rows.length; i++) {
      var k = rowKey(rows[i]);
      if (!k || map.has(k)) return null; // ключей нет или они не уникальны
      map.set(k, rows[i]);
    }
    return map;
  }

  function morphRows(liveBody, nextBody) {
    var liveRows = Array.prototype.slice.call(liveBody.children);
    var nextRows = Array.prototype.slice.call(nextBody.children);
    var liveMap = keyMap(liveRows);
    var nextMap = keyMap(nextRows);
    if (!liveMap || !nextMap) {
      // Без ключей — по порядку
      var changed = false;
      nextRows.forEach(function (n, i) {
        var l = liveBody.children[i];
        if (!l) { liveBody.appendChild(adopt(n)); changed = true; }
        else if (!sameKind(l, n)) { liveBody.replaceChild(adopt(n), l); changed = true; }
        else if (morphNode(l, n)) changed = true;
      });
      while (liveBody.children.length > nextRows.length) { liveBody.removeChild(liveBody.lastElementChild); changed = true; }
      return changed;
    }

    var changedRows = false;
    nextRows.forEach(function (n, i) {
      var key = rowKey(n);
      var l = liveMap.get(key);
      if (l) {
        liveMap.delete(key);
        if (morphNode(l, n)) changedRows = true;
      } else {
        l = adopt(n);
        changedRows = true;
      }
      var at = liveBody.children[i];
      if (at !== l) { liveBody.insertBefore(l, at || null); changedRows = true; }
    });
    liveMap.forEach(function (row) { row.remove(); changedRows = true; });
    return changedRows;
  }

  // ── Подсветка изменившихся чисел (как в биржевом стакане) ──────────
  var reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function toNumber(s) {
    var m = String(s).replace(/\s+/g, '').match(/[+\-]?\d+(\.\d+)?/);
    return m ? parseFloat(m[0]) : NaN;
  }

  function tickFlash(textNode, oldText, newText) {
    if (reducedMotion) return;
    var el = textNode.parentElement && textNode.parentElement.closest('.bt-num, .bt-stat-value');
    if (!el) return;
    var a = toNumber(oldText), b = toNumber(newText);
    if (isNaN(a) || isNaN(b) || a === b) return;
    var cls = b > a ? 'hb-tick-up' : 'hb-tick-down';
    el.classList.remove('hb-tick-up', 'hb-tick-down');
    requestAnimationFrame(function () { el.classList.add(cls); });
  }

  content.addEventListener('animationend', function (e) {
    var t = e.target;
    if (t.classList && (t.classList.contains('hb-tick-up') || t.classList.contains('hb-tick-down'))) {
      t.classList.remove('hb-tick-up', 'hb-tick-down');
    }
  });

  // ── События ────────────────────────────────────────────────────────
  function isContentRequest(evt) {
    var t = evt.detail && evt.detail.target;
    return t && t.id === 'htmx-content';
  }

  document.body.addEventListener('htmx:beforeRequest', function (evt) {
    if (!isContentRequest(evt)) return;
    contentLoading = true;
    if (inflight) { inflight.abort(); inflight = null; }
  });

  document.body.addEventListener('htmx:afterRequest', function (evt) {
    if (!isContentRequest(evt)) return;
    contentLoading = false;
    var xhr = evt.detail.xhr;
    var v = view();
    var path = '';
    try { path = new URL(xhr.responseURL, window.location.href).pathname; } catch (e) { }
    // В разделе открыли подстраницу (hx-target="#htmx-content") — её не обновляем
    showingView = !!evt.detail.successful && path === urlOf(v);
    if (showingView) etags[v] = xhr.getResponseHeader('ETag');
    // htmx 1.9 сообщает afterRequest уже после замены содержимого — отсюда и запускаем опрос
    unchanged = 0;
    failures = 0;
    schedule();
  });

  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { stop(); setStatus(isLive(view()) && showingView ? 'paused' : 'off'); }
    else schedule(0);
  });

  window.addEventListener('online', function () { failures = 0; schedule(0); });

  var modal = document.getElementById('htmx-modal');
  if (modal) modal.addEventListener('close', function () { schedule(150); });

  document.addEventListener('pointerdown', function () { pointerDown = true; }, true);
  document.addEventListener('pointerup', function () { pointerDown = false; }, true);
  document.addEventListener('pointercancel', function () { pointerDown = false; }, true);

  // Раздел мог загрузиться раньше этого скрипта (скрипт подключили позже или он грузился дольше ответа):
  // тогда событий его загрузки не было — подхватываем уже показанный раздел
  function adoptShownView() {
    if (showingView || !isLive(view()) || !content.firstElementChild) return;
    showingView = true;
    schedule();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', adoptShownView);
  else adoptShownView();

  // Для htmx_4.js: после действий пользователя (пауза бота, закрытие позиции) — обновить сразу
  window.hbLive = {
    handles: function (v) { return isLive(v) && showingView; },
    refreshNow: function () { unchanged = 0; schedule(0); }
  };
})();
